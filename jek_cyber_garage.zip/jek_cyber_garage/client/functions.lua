function _Client:RequestModel(model)
    local hash = GetHashKey(model)
    RequestModel(hash)
    while not HasModelLoaded(hash) do
        Wait(10)
    end
end

function _Client:RequestDict(dict)
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Wait(10)
    end
end

function _Client:RequestPtfxAssetDict(dict)
    RequestNamedPtfxAsset(dict)
    while not HasNamedPtfxAssetLoaded(dict) do
        Wait(10)
    end
end

function _Client:PlaySound(file, volume, forAll, coords, radius)
    if forAll then
        TriggerServerEvent("ZL_cyber:playSound", file, volume, coords, radius)
    else
        if coords then
            local playerPed = PlayerPedId()
            self.soundIsPlayed = true

            CreateThread(function()
                while self.soundIsPlayed do
                    local playerCoords = GetEntityCoords(playerPed)

                    if self:Distance(playerCoords, coords) <= radius then
                        SendNuiMessage(json.encode({
                            type   = "changeSoundVolume",
                            volume = volume
                        }))
                    else
                        SendNuiMessage(json.encode({
                            type   = "changeSoundVolume",
                            volume = 0.0
                        }))
                    end

                    Wait(500)
                end
            end)
        end

        SendNuiMessage(json.encode({
            type = "playSoundFile",
            file = file,
            volume = volume
        }))
    end
end

function _Client:SaveVehicle(vehicle)
    local vehicleProperties
    if Config.Framework == "ESX" then
        vehicleProperties = ESX.Game.GetVehicleProperties(vehicle)
    elseif Config.Framework == "QBCore" then
        vehicleProperties = QBCore.Functions.GetVehicleProperties(vehicle)
    end

    TriggerServerEvent('ZL_cyber:saveVehicle', vehicleProperties)
end

function _Client:HelpNotification(coords, text)
    if Config.HelpNotificationType == "BasicHelpNotification" then
        SetTextComponentFormat("STRING")
        AddTextComponentString(text)
        DisplayHelpTextFromStringLabel(0, 0, 1, -1)
    elseif Config.HelpNotificationType == "DrawText3D" then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(true)
        AddTextComponentString(text)
        SetDrawOrigin(coords, 0)
        DrawText(0.0, 0.0)
        local factor = (string.len(text)) / 370
        DrawRect(0.0, 0.0+0.0125, 0.017+ factor, 0.03, 0, 0, 0, 75)
        ClearDrawOrigin()
    elseif Config.HelpNotificationType == "Custom" then
        CustomHelpNotification(coords.x, coords.y, coords.z, text)
    end
end

function _Client:Notification(text, isError)
    if Config.NotificationType == "BasicNotification" then
        if Config.Framework == "ESX" then
            ESX.ShowNotification((isError and "~r~" or "") .. text)
        elseif Config.Framework == "QBCore" then
            QBCore.Functions.Notify(text, isError and "error" or "success")
        end
    elseif Config.NotificationType == "Custom" then
        CustomNotification(text, isError)
    end
end

function _Client:ToLang(textName)
    return Config.Languages[Config.Language][textName] or "Invalid Language translation"
end

function _Client:Distance(coords, coords2)
    return #(coords - coords2)
end

function _Client:GetTableLength(table)
    local count = 0
    for _ in pairs(table) do
        count = count + 1
    end
    return count
end

function _Client:TriggerCallback(event, cb, ...) 
    self.callbackList[event] = cb
    TriggerServerEvent("ZL_cyber:callback", event, cb, ...)
end

RegisterNetEvent("ZL_cyber:callback", function(event, param)
    if _Client.callbackList[event] then
        _Client.callbackList[event](param)
    end
end)