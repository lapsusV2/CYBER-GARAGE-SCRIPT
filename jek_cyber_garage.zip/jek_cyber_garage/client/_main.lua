_Client = class()

function _Client:init()
    self.callbackList = {}
    self.playerData   = {}
    self.soundIsPlayed = false

    for k,v in pairs(Config.Job.OrderParts.Items) do
        v.count = 1
    end

    _Client:SetConfig()
end

function _Client:SetConfig() 
    SendNuiMessage(json.encode({
        type = "setConfig",
        data = {
            translations = Config.Languages[Config.Language],
            job = {
                orderParts = {
                    needPassword = Config.Job.OrderParts.NeedPassword,
                    items        = Config.Job.OrderParts.Items,
                    categories   = Config.Job.OrderParts.Categories,
                }
            },
            paint = {
                types = Config.Paint.Types,
                matters = Config.Paint.Matters,
                pearlescentColors = Config.Paint.PearlescentColors 
            },
            resourceName = GetCurrentResourceName()
        }
    }))

    SetTimeout(15000, function()
        _Client:SetConfig()
    end)
end

CreateThread(function()
    if Config.Framework == "ESX" then
        while ESX == nil do
            TriggerEvent(Config.EventName.getSharedObject, function(object) ESX = object end)
            Wait(30)
        end
        _Client.playerData = ESX.GetPlayerData()
    elseif Config.Framework == "QBCore" then
        QBCore = exports[Config.EventName.getSharedObject]:GetCoreObject()
        _Client.playerData = QBCore.Functions.GetPlayerData()
    end

    while not _Client.playerData or not _Client.playerData.job do
        Wait(10)
    end
    
    if Config.Job.Activated then
        _Job:init()
    end

    if Config.Lift.Activated then
        _Lift:init()
    end
    
    if Config.Paint.Activated then
        _Paint:init()
    end

    if not Config.UseQBTarget then
        _Client:startLoop()
    end
end)

RegisterNetEvent(Config.EventName.playerLoaded, function(newPlayerData)
    if Config.Framework == "ESX" then
        _Client.playerData = newPlayerData
    elseif Config.Framework == "QBCore" then
        _Client.playerData = QBCore.Functions.GetPlayerData()
    end
end)

RegisterNetEvent(Config.EventName.playerJobUpdate, function(job)
    if Config.Framework == "ESX" then
        _Client.playerData.job = job
    elseif Config.Framework == "QBCore" then
        _Client.playerData.job = QBCore.Functions.GetPlayerData().job
    end
end)

function _Client:startLoop()
    while true do
        local isInZone = false
        local ped          = PlayerPedId()
        local playerCoords = GetEntityCoords(ped)

        isInZone = (Config.Lift.Activated and _Lift and _Lift:loop(playerCoords)) or (Config.Paint.Activated and _Paint and _Paint:loop(playerCoords)) or (Config.Job.Activated and _Job and _Job:loop(playerCoords)) or (Config.Job.Activated and _Wheel and _Wheel:loop(playerCoords))

        if isInZone then
            Wait(1)
        else
            Wait(500)
        end
    end
end

RegisterNetEvent("ZL_cyber:useItem", function(itemName)
    if string.find(itemName, "tyre") or string.find(itemName, "rim") then
        _Wheel:Use(itemName)
    elseif itemName == "carjack" then
        _Job:UseItem(itemName)
    end
end)

RegisterNetEvent("ZL_cyber:sendNotification", function(textName, isError)
    _Client:Notification(_Client:ToLang(textName), isError)
end)

RegisterNetEvent("ZL_cyber:playSound", function(file, volume, coords, radius)
    _Client:PlaySound(file, volume, false, coords, radius)
end)

RegisterNUICallback("onSoundEnded", function()
    _Client.soundIsPlayed = false
end)

_Client:init()