_Wheel = _Job:extend()

function _Wheel:init()
    --self.props = {}
    self.stocks = {}
    self.countPerStage = 11
    self.stageCount = 4
    self.tyreOffset = Config.Job.Shelves.TyreOffset
    self.textOffset = Config.Job.Shelves.TextOffset
    self.qbtargetOffset = Config.Job.Shelves.QBTargetOffset
    self.shelvesCoords = Config.Job.Shelves.Coords
    
    self.tyreHandProps  = nil
    self.isInShelf       = false
    self.InstructionalScaleform = RequestScaleformMovie("INSTRUCTIONAL_BUTTONS")
    self.InstructionalButtons   = {
        {"~INPUT_FRONTEND_RRIGHT~", _Client:ToLang("CANCEL")},
        {"~INPUT_CELLPHONE_DOWN~", _Client:ToLang("DOWN")},
        {"~INPUT_CELLPHONE_UP~", _Client:ToLang("UP")},
        {"~INPUT_CELLPHONE_RIGHT~", _Client:ToLang("RIGHT")},
        {"~INPUT_CELLPHONE_LEFT~", _Client:ToLang("LEFT")},
    }
    self.indexType = {
        ["sport"]     = 0,
        ["muscle"]    = 1,
        ["lowrider"]  = 2,
        ["suv"]       = 3,
        ["offroad"]   = 4,
        ["tuner"]     = 5,
        ["motorcyle"] = 6,
        ["highend"]   = 7,
        ["bennys"]    = 8,
        ["bespoke"]   = 9,
        ["f1"]        = 10,
        ["street"]    = 11
    }
    self.bones = {
        "wheel_lf",
        "wheel_rf",
        "wheel_lr",
        "wheel_rr"
    }

    _Client:TriggerCallback("getTyresStocks", function(stocks)
        self.stocks = stocks
    end)

    self:InitObjects()

    if Config.UseQBTarget then
        self:CreateQBTarget()
    end
end

function _Wheel:loop(playerCoords)
    local isInZone = false

    if self.tyreHandProps or (_Client.playerData.job and Config.Job.Name == _Client.playerData.job.name) then
        for i = 1, #self.shelvesCoords do
            if _Client:Distance(self.shelvesCoords[i], playerCoords) < 3.0 then
                _Client:HelpNotification(vector3(self.shelvesCoords[i].x + self.textOffset[i].x, self.shelvesCoords[i].y + self.textOffset[i].y, self.shelvesCoords[i].z + self.textOffset[i].z), _Client:ToLang(self.tyreHandProps and "PUT_TYRE_IN_SHELF" or "GET_TYRE_IN_SHELF"):format("E"))
                if IsControlJustReleased(0, 38) then
                    local isAlreadyUsed
                    local waitUse = promise.new()

                    _Client:TriggerCallback("changeTyreShelfStatus", function(isUse)
                        isAlreadyUse = isUse         
                        waitUse:resolve()
                    end, i)

                    Citizen.Await(waitUse)

                    if not isAlreadyUse then
                        if self.tyreHandProps and GetEntityAttachedTo(self.tyreHandProps) == PlayerPedId() and (not self.rimHandProps or GetEntityAttachedTo(self.rimHandProps) ~= PlayerPedId()) then
                            self:PutTyreInShelf(i)
                        elseif not self.tyreHandProps and (not self.rimHandProps or GetEntityAttachedTo(self.rimHandProps) ~= PlayerPedId()) then
                            self:GetTyreInShelf(i)
                        end
                    else
                        _Client:Notification(_Client:ToLang("TYRE_SHELF_ALREADY_IN_USE"), true)
                    end
                end
                isInZone = true
            end
        end
        
        if _Client.playerData.job and Config.Job.Name == _Client.playerData.job.name and not isInZone then
            if _Client:Distance(Config.Job.WheelMachine.Interaction, playerCoords) <= 0.75 then
                local drawCoords = Config.Job.WheelMachine.TextCoords
                if self.tyreHandProps and GetEntityAttachedTo(self.tyreHandProps) == PlayerPedId() and GetEntityAttachedTo(self.rimHandProps) ~= self.tyreHandProps then
                    _Client:HelpNotification(drawCoords, _Client:ToLang("PLACE_TYRE_ON_DISK_HELP_NOTIFICATION"):format("E"))

                    if IsControlJustReleased(0, 38) then
                        DetachEntity(self.tyreHandProps)
                        ClearPedTasks(PlayerPedId())
                        self:AttachTyre(self.diskProps)
                    end

                    isInZone = true

                    goto endCheck
                end

                if self.rimHandProps and GetEntityAttachedTo(self.rimHandProps) == PlayerPedId() then
                    _Client:HelpNotification(drawCoords, _Client:ToLang("PLACE_RIM_ON_DISK_HELP_NOTIFICATION"):format("E"))

                    if IsControlJustReleased(0, 38) then
                        DetachEntity(self.rimHandProps)
                        ClearPedTasks(PlayerPedId())
                        self:AttachRim(self.diskProps)
                    end

                    isInZone = true

                    goto endCheck
                end

                if GetEntityAttachedTo(self.tyreHandProps) == PlayerPedId() and GetEntityAttachedTo(self.rimHandProps) == self.tyreHandProps then
                    _Client:HelpNotification(drawCoords, _Client:ToLang("PLACE_WHEEL_ON_DISK_HELP_NOTIFICATION"):format("E"))

                    if IsControlJustReleased(0, 38) then
                        DetachEntity(self.tyreHandProps)
                        DetachEntity(self.rimHandProps)
                        ClearPedTasks(PlayerPedId())
                        self:AttachTyre(self.diskProps, {rotationY = 0.0})
                        self:AttachRim(self.diskProps)
                    end

                    isInZone = true

                    goto endCheck
                end

                if GetEntityAttachedTo(self.tyreHandProps) == self.diskProps and GetEntityAttachedTo(self.rimHandProps) ~= PlayerPedId() and GetEntityRotation(self.tyreHandProps).y < -5.0 then
                    if GetEntityAttachedTo(self.rimHandProps) == self.diskProps then
                        if Config.HelpNotificationType == "BasicHelpNotification" then
                            _Client:HelpNotification(drawCoords, _Client:ToLang("TAKE_TYRE_HELP_NOTIFICATION"):format("E") .. "\n" .. _Client:ToLang("TAKE_RIM_HELP_NOTIFICATION"):format("G"))
                        else
                            _Client:HelpNotification(drawCoords, _Client:ToLang("TAKE_TYRE_HELP_NOTIFICATION"):format("E"))
                            _Client:HelpNotification(vector3(drawCoords.x, drawCoords.y, drawCoords.z - 0.15), _Client:ToLang("TAKE_RIM_HELP_NOTIFICATION"):format("G"))
                        end

                        if IsControlJustReleased(0, 38) then
                            self:AttachTyre(PlayerPedId())
                        end
                        
                        if IsControlJustReleased(0, 113) then
                            self:AttachRim(PlayerPedId())
                        end

                        isInZone = true

                        goto endCheck
                    end

                    _Client:HelpNotification(drawCoords, _Client:ToLang("TAKE_TYRE_HELP_NOTIFICATION"):format("E"))
                    
                    if IsControlJustReleased(0, 38) then
                        self:AttachTyre(PlayerPedId())
                    end

                    isInZone = true

                    goto endCheck
                end

                if GetEntityAttachedTo(self.rimHandProps) == self.diskProps and ((GetEntityAttachedTo(self.tyreHandProps) ~= PlayerPedId() and GetEntityRotation(self.tyreHandProps).y < -5.0) or not self.tyreHandProps) then
                    _Client:HelpNotification(drawCoords, _Client:ToLang("TAKE_RIM_HELP_NOTIFICATION"):format("E"))
                    
                    if IsControlJustReleased(0, 38) then
                        self:AttachRim(PlayerPedId())
                    end

                    isInZone = true

                    goto endCheck
                end

                if GetEntityAttachedTo(self.rimHandProps) == self.diskProps and GetEntityAttachedTo(self.tyreHandProps) == self.diskProps and GetEntityRotation(self.tyreHandProps).y > -5.0 then
                    _Client:HelpNotification(drawCoords, _Client:ToLang("TAKE_WHEEL_HELP_NOTIFICATION"):format("E"))
                    
                    if IsControlJustReleased(0, 38) then
                        DetachEntity(self.tyreHandProps)
                        DetachEntity(self.rimHandProps)
                        self:AttachTyre(PlayerPedId())
                        self:AttachRim(self.tyreHandProps)
                    end

                    isInZone = true

                    goto endCheck
                end

                ::endCheck::
            end

            if _Client:Distance(Config.Job.WheelMachine.StartMachine, playerCoords) <= 0.75 and GetEntityAttachedTo(self.tyreHandProps) == self.diskProps and GetEntityAttachedTo(self.rimHandProps) == self.diskProps then

                _Client:HelpNotification(Config.Job.WheelMachine.StartMachine, _Client:ToLang("START_MACHINE_HELP_NOTIFICATION"):format("E"))

                if IsControlJustReleased(0, 38) then
                    local isAWheel = false
                    if GetEntityRotation(self.tyreHandProps).y > -5.0 then
                        isAWheel = true
                    end

                    self:StartMachine(isAWheel)
                end

                isInZone = true
            end
        end
    end

    return isInZone
end

RegisterNetEvent("ZL_cyber:updateTyresStocks", function(stocks)
    _Wheel.stocks = stocks
end)

RegisterNetEvent("ZL_cyber:putTyreInShelf", function(data)
    _Wheel:PutTyreInShelf(data.shelfIndex)
end)

RegisterNetEvent("ZL_cyber:getTyreInShelf", function(data)
    _Wheel:GetTyreInShelf(data.shelfIndex)
end)

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName == GetCurrentResourceName() then
        DeleteEntity(shelf)
        DeleteEntity(_Wheel.tyreHandProps)
        DeleteEntity(_Wheel.stickProps)
        DeleteEntity(_Wheel.diskProps)
        DeleteEntity(_Wheel.rimHandProps)
        DeleteEntity(_Wheel.machineProps)

        ClearPedTasks(PlayerPedId())
    end
end)