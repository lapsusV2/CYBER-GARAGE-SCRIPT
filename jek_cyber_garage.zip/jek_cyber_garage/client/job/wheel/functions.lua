function _Wheel:InitObjects()
    local machinePropsName = "garmx_machine"
    local stickPropsName = "garmxbat"
    local diskPropsName  = "garmxdisque"

    _Client:RequestModel(machinePropsName)
    _Client:RequestModel(stickPropsName)
    _Client:RequestModel(diskPropsName)

    self.machineProps = CreateObject(machinePropsName, Config.Job.WheelMachine.Coords, 0, 1, 0)
    SetModelAsNoLongerNeeded(machinePropsName)
    SetEntityLodDist(self.machineProps, 0xFFFF)
    SetEntityCollision(self.machineProps, true, true)
    FreezeEntityPosition(self.machineProps, true)
    SetEntityCoords(self.machineProps, Config.Job.WheelMachine.Coords)  

    self.stickProps = CreateObject(stickPropsName, vector3(0, 0, 0), 0, 1, 0)
    SetModelAsNoLongerNeeded(stickPropsName)
    SetEntityLodDist(self.stickProps, 0xFFFF)
    SetEntityCollision(self.stickProps, true, true)
    AttachEntityToEntity(self.stickProps, self.machineProps, 0, 0.15, 0.17, 0.98, 0.0, 0.0, 0.0, 0, 0, 1, 0, 0, 1)

    self.diskProps = CreateObject(diskPropsName, vector3(0, 0, 0), 0, 1, 0)
    SetModelAsNoLongerNeeded(diskPropsName)
    SetEntityLodDist(self.diskProps, 0xFFFF)
    SetEntityCollision(self.diskProps, true, true)
    AttachEntityToEntity(self.diskProps, self.machineProps, 0, 0.15, 0.25, -0.02, 0.0, 0.0, 0.0, 0, 0, 1, 0, 0, 1)
end

function _Wheel:RemoveVehicleWheel(vehicle, wheelIndex)
    Entity(vehicle).state["xOffset_" .. wheelIndex] = GetVehicleWheelXOffset(vehicle, wheelIndex)
    Entity(vehicle).state["flags_" .. wheelIndex] = GetVehicleWheelFlags(vehicle, wheelIndex)

    SetVehicleWheelHealth(vehicle, wheelIndex, 0.0)
    SetVehicleWheelXOffset(vehicle, wheelIndex, 9999.0)
    SetVehicleWheelFlags(vehicle, wheelIndex, -1)
end

function _Wheel:AddVehicleWheel(vehicle, wheelIndex)
    SetVehicleWheelHealth(vehicle, wheelIndex, 100.0)
    SetVehicleWheelXOffset(vehicle, wheelIndex, Entity(vehicle).state["xOffset_" .. wheelIndex])
    SetVehicleWheelFlags(vehicle, wheelIndex, Entity(vehicle).state["flags_" .. wheelIndex])
    SetVehicleTyreFixed(vehicle, wheelIndex)

    Entity(vehicle).state["xOffset_" .. wheelIndex] = nil
    Entity(vehicle).state["flags_" .. wheelIndex] = nil
end

function _Wheel:AddProp(propType, wheelType)
    if propType == "tyre" then
        _Client:RequestModel("imp_prop_impexp_tyre_03a")
        
        local tyre = CreateObject("imp_prop_impexp_tyre_03a", 0, 0, 0, 1, 1, 0)
        SetModelAsNoLongerNeeded("imp_prop_impexp_tyre_03a")
        SetEntityAsMissionEntity(tyre, 1, 1)
        Entity(tyre).state.type = wheelType
        self.tyreHandProps = tyre

        if Config.UseQBTarget then
            self:UpdateShelfTarget({
                type  = "client",
                event = "ZL_cyber:putTyreInShelf",
                icon  = "fas fa-gear",
                label = _Client:ToLang("PUT_TYRE_ON_SHELF"),
                job   = Config.Job.Name,
                canInteract = function()
                    return ((self.rimHandProps == nil or GetEntityAttachedTo(self.rimHandProps) ~= PlayerPedId()) and self.tyreHandProps and GetEntityAttachedTo(self.tyreHandProps) == PlayerPedId()) and true or false
                end
            })
        end
    elseif propType == "rim" then
        _Client:RequestModel("prop_wheel_rim_01")

        local rim = CreateObject("prop_wheel_rim_01", 0, 0, 0, 1, 1, 0)
        SetModelAsNoLongerNeeded("prop_wheel_rim_01")
    
        self.rimHandProps = rim
    end
end

function _Wheel:AttachTyre(attachTo, options)
    if not self.tyreHandProps then return end

    if attachTo == PlayerPedId() then
        _Client:RequestDict("anim@heists@box_carry@")
        TaskPlayAnim(attachTo, "anim@heists@box_carry@", "idle", 6.0, -2.0, -1, 50, 0, 0, 0, 0)
        AttachEntityToEntity(self.tyreHandProps, attachTo, GetPedBoneIndex(attachTo, 28422), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1, 1, 0, 1, 1, 1)
        CreateThread(function()
            Wait(500)

            while self.tyreHandProps and GetEntityAttachedTo(self.tyreHandProps) == PlayerPedId() do
                Wait(1)

                if (not self.rimHandProps or GetEntityAttachedTo(self.rimHandProps) ~= self.tyreHandProps) and GetEntityAttachedTo(self.tyreHandProps) == PlayerPedId() then
                    if IsControlJustReleased(0, 202) then
                        local wheelType = Entity(self.tyreHandProps).state.type
                        self:RemoveTyre()
                        TriggerServerEvent("ZL_cyber:addItem", "tyre_" .. wheelType, 1)
                    end

                    BeginScaleformMovieMethod(self.InstructionalScaleform, "CLEAR_ALL")
                    EndScaleformMovieMethod()
                
                    BeginScaleformMovieMethod(self.InstructionalScaleform, "TOGGLE_MOUSE_BUTTONS")
                    ScaleformMovieMethodAddParamInt(0)
                    EndScaleformMovieMethod()
                
                    BeginScaleformMovieMethod(self.InstructionalScaleform, "CREATE_CONTAINER")
                    EndScaleformMovieMethod()

                    BeginScaleformMovieMethod(self.InstructionalScaleform, "SET_DATA_SLOT")
                    ScaleformMovieMethodAddParamInt(1)
                    PushScaleformMovieMethodParameterButtonName("~INPUT_FRONTEND_RRIGHT~")
                    PushScaleformMovieMethodParameterString(_Client:ToLang("STORE_TYRE"))
                    EndScaleformMovieMethod()

                    BeginScaleformMovieMethod(self.InstructionalScaleform, "DRAW_INSTRUCTIONAL_BUTTONS")
                    ScaleformMovieMethodAddParamInt(-1)
                    EndScaleformMovieMethod()
                
                    DrawScaleformMovieFullscreen(self.InstructionalScaleform, 255, 255, 255, 255, 0)
                end
            end
        end)
    elseif attachTo == self.diskProps then
        AttachEntityToEntity(self.tyreHandProps, attachTo, 0, 0.0, 0.0, 0.125, 90.0, (options and options.rotationY) and options.rotationY or -10.0, 0.0, 1, 1, 0, 0, 1, 1)
    end
end

function _Wheel:AttachRim(attachTo)
    if not self.rimHandProps then return end

    if attachTo == PlayerPedId() then
        _Client:RequestDict("anim@heists@box_carry@")
        TaskPlayAnim(attachTo, "anim@heists@box_carry@", "idle", 6.0, -2.0, -1, 50, 0, 0, 0, 0)
        AttachEntityToEntity(self.rimHandProps, attachTo, GetPedBoneIndex(attachTo, 28422), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1, 1, 0, 1, 1, 1)
        CreateThread(function()
            Wait(500)

            while self.rimHandProps do
                Wait(1)

                if GetEntityAttachedTo(self.rimHandProps) == PlayerPedId() then
                    if IsControlJustReleased(0, 202) then
                        self:RemoveRim()
                        TriggerServerEvent("ZL_cyber:addItem", "rim", 1)
                    end

                    BeginScaleformMovieMethod(self.InstructionalScaleform, "CLEAR_ALL")
                    EndScaleformMovieMethod()
                
                    BeginScaleformMovieMethod(self.InstructionalScaleform, "TOGGLE_MOUSE_BUTTONS")
                    ScaleformMovieMethodAddParamInt(0)
                    EndScaleformMovieMethod()
                
                    BeginScaleformMovieMethod(self.InstructionalScaleform, "CREATE_CONTAINER")
                    EndScaleformMovieMethod()

                    BeginScaleformMovieMethod(self.InstructionalScaleform, "SET_DATA_SLOT")
                    ScaleformMovieMethodAddParamInt(1)
                    PushScaleformMovieMethodParameterButtonName("~INPUT_FRONTEND_RRIGHT~")
                    PushScaleformMovieMethodParameterString(_Client:ToLang("STORE_RIM"))
                    EndScaleformMovieMethod()

                    BeginScaleformMovieMethod(self.InstructionalScaleform, "DRAW_INSTRUCTIONAL_BUTTONS")
                    ScaleformMovieMethodAddParamInt(-1)
                    EndScaleformMovieMethod()
                
                    DrawScaleformMovieFullscreen(self.InstructionalScaleform, 255, 255, 255, 255, 0)
                end
            end
        end)
    elseif attachTo == self.tyreHandProps then
        AttachEntityToEntity(self.rimHandProps, self.tyreHandProps, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1, 1, 0, 0, 1, 1)
    elseif attachTo == self.diskProps then
        AttachEntityToEntity(self.rimHandProps, self.diskProps, 0, 0.0, 0.0, 0.15, 90.0, 180.0, 0.0, 1, 1, 0, 0, 1, 1)
    end
end

function _Wheel:RemoveTyre()
    if GetEntityAttachedTo(self.tyreHandProps) == PlayerPedId() then
        ClearPedTasks(PlayerPedId())
    end

    DeleteEntity(self.tyreHandProps)
    self.tyreHandProps = nil

    if Config.UseQBTarget then
        self:UpdateShelfTarget({
            type  = "client",
            event = "ZL_cyber:getTyreInShelf",
            icon  = "fas fa-gear",
            label = _Client:ToLang("GET_TYRE_FROM_SHELF"),
            job   = Config.Job.Name,
            canInteract = function()
                return (self.rimHandProps == nil and self.tyreHandProps == nil) and true or false
            end
        })
    end
end

function _Wheel:RemoveRim()
    if GetEntityAttachedTo(self.rimHandProps) == PlayerPedId() then
        ClearPedTasks(PlayerPedId())
    end
    
    DetachEntity(self.rimHandProps)
    DeleteEntity(self.rimHandProps)
    self.rimHandProps = nil
end

function _Wheel:DrawScaleformButtonsShelf(buttons)
    BeginScaleformMovieMethod(self.InstructionalScaleform, "CLEAR_ALL")
    EndScaleformMovieMethod()

    BeginScaleformMovieMethod(self.InstructionalScaleform, "TOGGLE_MOUSE_BUTTONS")
    ScaleformMovieMethodAddParamInt(0)
    EndScaleformMovieMethod()

    BeginScaleformMovieMethod(self.InstructionalScaleform, "CREATE_CONTAINER")
    EndScaleformMovieMethod()

    local buttonCount = 0
    for i = 1, #buttons do
        buttonCount += 1

        BeginScaleformMovieMethod(self.InstructionalScaleform, "SET_DATA_SLOT")
        ScaleformMovieMethodAddParamInt(buttonCount)
        PushScaleformMovieMethodParameterButtonName(buttons[i][1])
        PushScaleformMovieMethodParameterString(buttons[i][2])
        EndScaleformMovieMethod()
    end

    for i = 1, #self.InstructionalButtons do
        buttonCount += 1
        
        BeginScaleformMovieMethod(self.InstructionalScaleform, "SET_DATA_SLOT")
        ScaleformMovieMethodAddParamInt(buttonCount)
        PushScaleformMovieMethodParameterButtonName(self.InstructionalButtons[i][1])
        PushScaleformMovieMethodParameterString(self.InstructionalButtons[i][2])
        EndScaleformMovieMethod()
    end

    BeginScaleformMovieMethod(self.InstructionalScaleform, "DRAW_INSTRUCTIONAL_BUTTONS")
    ScaleformMovieMethodAddParamInt(-1)
    EndScaleformMovieMethod()

    DrawScaleformMovieFullscreen(self.InstructionalScaleform, 255, 255, 255, 255, 0)
end

function _Wheel:PutTyreInShelf(shelfIndex)
    _Client:RequestModel("imp_prop_impexp_tyre_03a")

    local playerPed = PlayerPedId()
    ClearPedTasks(playerPed)
    self.isInShelf = true

    self.currentCam = CreateCameraWithParams("DEFAULT_SCRIPTED_CAMERA", self.shelvesCoords[shelfIndex].x - 4.0 + self.tyreOffset[shelfIndex].x * 0, self.shelvesCoords[shelfIndex].y + self.tyreOffset[shelfIndex].y * (self.countPerStage / 2), self.shelvesCoords[shelfIndex].z + self.tyreOffset[shelfIndex].z * 2.75, -5.0, 0.0, -90.0, 50.0, 0, 0)
    SetCamActive(self.currentCam, true)
    RenderScriptCams(1, 0, 0, 0, 0)

    local shelfPlaces = self.stocks["shelves_" .. shelfIndex]
    local currentIndex = 1
    local currentStage = 1
    local previewTyre  = self.tyreHandProps

    self.tyreHandProps = nil

    for i = 1, #shelfPlaces do
        if not shelfPlaces[i] then
            local coords = vector3(self.shelvesCoords[shelfIndex].x + self.tyreOffset[shelfIndex].x * currentIndex, self.shelvesCoords[shelfIndex].y + self.tyreOffset[shelfIndex].y * currentIndex, self.shelvesCoords[shelfIndex].z + self.tyreOffset[shelfIndex].z * currentStage)
            DetachEntity(previewTyre, 0, 0)
            SetEntityRotation(previewTyre, 0.0, 0.0, 0.0, 0, 0)
            SetEntityCoords(previewTyre, coords)
            break
        end

        currentIndex += 1
        if currentIndex == 11 then
            currentIndex = 0
            currentStage += 1
        end
    end

    while self.isInShelf do
        local tyreIndexInShelf = currentIndex + (self.countPerStage * (currentStage - 1))

        DrawMarker(20, self.shelvesCoords[shelfIndex].x - self.tyreOffset[shelfIndex].x * currentIndex - 0.4, self.shelvesCoords[shelfIndex].y + self.tyreOffset[shelfIndex].y * currentIndex, self.shelvesCoords[shelfIndex].z + self.tyreOffset[shelfIndex].z * currentStage + 0.1, 90.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 0, 255, 0, 255, 1, 0, 0, 0, 0, 0, 0)

        if IsControlJustReleased(0, 174) and currentIndex > 1 then
            currentIndex -= 1

            SetEntityCoords(previewTyre, self.shelvesCoords[shelfIndex].x + self.tyreOffset[shelfIndex].x * currentIndex, self.shelvesCoords[shelfIndex].y + self.tyreOffset[shelfIndex].y * currentIndex, self.shelvesCoords[shelfIndex].z + self.tyreOffset[shelfIndex].z * currentStage)
        end

        if IsControlJustReleased(0, 175) and currentIndex < self.countPerStage then
            currentIndex += 1

            SetEntityCoords(previewTyre, self.shelvesCoords[shelfIndex].x + self.tyreOffset[shelfIndex].x * currentIndex, self.shelvesCoords[shelfIndex].y + self.tyreOffset[shelfIndex].y * currentIndex, self.shelvesCoords[shelfIndex].z + self.tyreOffset[shelfIndex].z * currentStage)
        end

        if IsControlJustReleased(0, 172) and currentStage < self.stageCount then
            currentStage += 1

            SetEntityCoords(previewTyre, self.shelvesCoords[shelfIndex].x + self.tyreOffset[shelfIndex].x * currentIndex, self.shelvesCoords[shelfIndex].y + self.tyreOffset[shelfIndex].y * currentIndex, self.shelvesCoords[shelfIndex].z + self.tyreOffset[shelfIndex].z * currentStage)
        end

        if IsControlJustReleased(0, 173) and currentStage > 1 then
            currentStage -= 1

            SetEntityCoords(previewTyre, self.shelvesCoords[shelfIndex].x + self.tyreOffset[shelfIndex].x * currentIndex, self.shelvesCoords[shelfIndex].y + self.tyreOffset[shelfIndex].y * currentIndex, self.shelvesCoords[shelfIndex].z + self.tyreOffset[shelfIndex].z * currentStage)
        end

        if IsControlJustReleased(0, 201) and not self.stocks["shelves_" .. shelfIndex][tyreIndexInShelf] then
            self.isInShelf = false
            TriggerServerEvent("ZL_cyber:placeTyreInShelf", shelfIndex, currentIndex, currentStage, Entity(previewTyre).state.type)
            self.tyreHandProps = previewTyre
            self:RemoveTyre()
        end

        if IsControlJustReleased(0, 202) then
            self.isInShelf = false
            self.tyreHandProps = previewTyre
            self:AttachTyre(PlayerPedId())
        end

        local buttons = {}

        if not self.stocks["shelves_" .. shelfIndex][tyreIndexInShelf] then
            table.insert(buttons, {"~INPUT_FRONTEND_ACCEPT~", _Client:ToLang("PUT_TYRE")})
        end

        self:DrawScaleformButtonsShelf(buttons)

        Wait(1)
    end

    _Client:TriggerCallback("changeTyreShelfStatus", function()
        self.currentCam = nil
        DestroyAllCams(false)
        RenderScriptCams(0, 0, 0, 0, 0)
    end, shelfIndex)
end

function _Wheel:GetTyreInShelf(shelfIndex)
    self.currentCam = CreateCameraWithParams("DEFAULT_SCRIPTED_CAMERA", self.shelvesCoords[shelfIndex].x - 4.0 - self.tyreOffset[shelfIndex].x * 0, self.shelvesCoords[shelfIndex].y + self.tyreOffset[shelfIndex].y * (self.countPerStage / 2), self.shelvesCoords[shelfIndex].z + self.tyreOffset[shelfIndex].z * 2.75, -5.0, 0.0, -90.0, 50.0, 0, 0)
    SetCamActive(self.currentCam, true)
    RenderScriptCams(1, 0, 0, 0, 0)

    local shelfPlaces = self.stocks["shelves_" .. shelfIndex]
    local currentIndex = 1
    local currentStage = 1

    self.isInShelf = true

    while self.isInShelf do
        local tyreIndexInShelf = currentIndex + (self.countPerStage * (currentStage - 1))

        DrawMarker(20, self.shelvesCoords[shelfIndex].x - self.tyreOffset[shelfIndex].x * currentIndex - 0.4, self.shelvesCoords[shelfIndex].y + self.tyreOffset[shelfIndex].y * currentIndex, self.shelvesCoords[shelfIndex].z + self.tyreOffset[shelfIndex].z * currentStage + 0.1, 90.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.2, 0.2, 0.2, 0, 150, 255, 175, 0, 0, 0, 0, 0, 0, 0)

        if self.stocks["shelves_" .. shelfIndex][tyreIndexInShelf] then
            SetTextScale(0.45, 0.45)
            SetTextFont(4)
            SetTextProportional(1)
            SetTextColour(0, 150, 255, 215)
            SetTextEntry("STRING")
            SetTextCentre(true)
            AddTextComponentString(_Client:ToLang("ITEM_LABEL_TYRE_" .. string.upper(self.stocks["shelves_" .. shelfIndex][tyreIndexInShelf])))
            SetDrawOrigin(self.shelvesCoords[shelfIndex].x - self.tyreOffset[shelfIndex].x * currentIndex - 0.4, self.shelvesCoords[shelfIndex].y + self.tyreOffset[shelfIndex].y * currentIndex, self.shelvesCoords[shelfIndex].z + self.tyreOffset[shelfIndex].z * currentStage - 0.0, 0)
            DrawText(0.0, 0.0)
            local factor = (string.len(_Client:ToLang("ITEM_LABEL_TYRE_" .. string.upper(self.stocks["shelves_" .. shelfIndex][tyreIndexInShelf])))) / 370
            DrawRect(0.0, 0.0+0.0160, 0.025 + factor, 0.03, 0, 0, 0, 140)
            ClearDrawOrigin()
        end

        if IsControlJustReleased(0, 174) and currentIndex > 1 then
            currentIndex -= 1
        end

        if IsControlJustReleased(0, 175) and currentIndex < self.countPerStage then
            currentIndex += 1
        end

        if IsControlJustReleased(0, 172) and currentStage < self.stageCount then
            currentStage += 1
        end

        if IsControlJustReleased(0, 173) and currentStage > 1 then
            currentStage -= 1
        end

        if IsControlJustReleased(0, 201) and self.stocks["shelves_" .. shelfIndex][tyreIndexInShelf] then
            self.isInShelf = false
            TriggerServerEvent("ZL_cyber:getTyreInShelf", shelfIndex, tyreIndexInShelf)
            self:AddProp("tyre", self.stocks["shelves_" .. shelfIndex][tyreIndexInShelf])
            self:AttachTyre(PlayerPedId())
        end

        if IsControlJustReleased(0, 202) then
            self.isInShelf = false
        end

        local buttons = {}

        if self.stocks["shelves_" .. shelfIndex][tyreIndexInShelf] then
            table.insert(buttons, {"~INPUT_FRONTEND_ACCEPT~", _Client:ToLang("GET_TYRE")})
        end

        self:DrawScaleformButtonsShelf(buttons)

        Wait(1)
    end

    _Client:TriggerCallback("changeTyreShelfStatus", function()
        self.currentCam = nil
        DestroyAllCams(false)
        RenderScriptCams(0, 0, 0, 0, 0)
    end, shelfIndex)
end

function _Wheel:CreateQBTarget()
    for i = 1, #self.shelvesCoords do
        exports[Config.QBTargetName]:AddBoxZone("cyber_shelves_" .. i, vector3(self.shelvesCoords[i].x + self.qbtargetOffset[i].x, self.shelvesCoords[i].y + self.qbtargetOffset[i].y, self.shelvesCoords[i].z + self.qbtargetOffset[i].z), 4.0, 0.7, {
            name = "cyber_shelves_" .. i,
            heading = 0,
            debugPoly = Config.Job.Shelves.QBTarget[i].debug,
            minZ = Config.Job.Shelves.QBTarget[i].minZ,
            maxZ = Config.Job.Shelves.QBTarget[i].maxZ
        }, {
            options = {
                {
                    type  = "client",
                    event = "ZL_cyber:getTyreInShelf",
                    icon  = "fas fa-gear",
                    label = _Client:ToLang("GET_TYRE_FROM_SHELF"),
                    job   = Config.Job.Name,
                    shelfIndex = i,
                    canInteract = function()
                        return (self.rimHandProps == nil and self.tyreHandProps == nil) and true or false
                    end
                }
            },
            distance = Config.Job.Shelves.QBTarget[i].distance
        })
    end

    exports[Config.QBTargetName]:AddTargetEntity(self.diskProps, {
        options = {
            {
                type  = "client",
                icon  = "fas fa-gear",
                label = _Client:ToLang("PLACE_WHEEL_ON_DISK"),
                job   = Config.Job.Name,
                canInteract = function()
                    return (self.tyreHandProps and self.rimHandProps and GetEntityAttachedTo(self.tyreHandProps) == PlayerPedId() and GetEntityAttachedTo(self.rimHandProps) == self.tyreHandProps) and true or false
                end,
                action = function()
                    DetachEntity(self.tyreHandProps)
                    DetachEntity(self.rimHandProps)
                    ClearPedTasks(PlayerPedId())

                    self:AttachTyre(self.diskProps, {
                        rotationY = 0.0
                    })
                    self:AttachRim(self.diskProps)
                end
            },
            {
                type  = "client",
                icon  = "fas fa-gear",
                label = _Client:ToLang("PLACE_TYRE_ON_DISK"),
                job   = Config.Job.Name,
                canInteract = function()
                    return (self.tyreHandProps and GetEntityAttachedTo(self.tyreHandProps) == PlayerPedId() and (not self.rimHandProps or GetEntityAttachedTo(self.rimHandProps) ~= self.tyreHandProps)) and true or false
                end,
                action = function()

                    DetachEntity(self.tyreHandProps)
                    ClearPedTasks(PlayerPedId())

                    self:AttachTyre(self.diskProps)
                end
            },
            {
                type  = "client",
                icon  = "fas fa-gear",
                label = _Client:ToLang("PLACE_RIM_ON_DISK"),
                job   = Config.Job.Name,
                canInteract = function()
                    return (self.rimHandProps and GetEntityAttachedTo(self.rimHandProps) == PlayerPedId()) and true or false
                end,
                action = function()

                    DetachEntity(self.rimHandProps)
                    ClearPedTasks(PlayerPedId())

                    self:AttachRim(self.diskProps)
                end
            },
            {
                type  = "client",
                icon  = "fas fa-gear",
                label = _Client:ToLang("TAKE_WHEEL"),
                job   = Config.Job.Name,
                canInteract = function()
                    return (GetEntityAttachedTo(self.rimHandProps) == self.diskProps and GetEntityAttachedTo(self.tyreHandProps) == self.diskProps and GetEntityRotation(self.tyreHandProps).y > -5.0) and true or false
                end,
                action = function()
                    DetachEntity(self.tyreHandProps)
                    DetachEntity(self.rimHandProps)
                    self:AttachTyre(PlayerPedId())
                    self:AttachRim(self.tyreHandProps)
                end
            },
            {
                type  = "client",
                icon  = "fas fa-gear",
                label = _Client:ToLang("TAKE_TYRE"),
                job   = Config.Job.Name,
                canInteract = function()
                    return (GetEntityAttachedTo(self.tyreHandProps) == self.diskProps and GetEntityAttachedTo(self.rimHandProps) ~= PlayerPedId() and GetEntityRotation(self.tyreHandProps).y < -5.0) and true or false
                end,
                action = function()
                    DetachEntity(self.tyreHandProps)
                    self:AttachTyre(PlayerPedId())
                end
            },
            {
                type  = "client",
                icon  = "fas fa-gear",
                label = _Client:ToLang("TAKE_RIM"),
                job   = Config.Job.Name,
                canInteract = function()
                    return (GetEntityAttachedTo(self.rimHandProps) == self.diskProps and ((GetEntityAttachedTo(self.tyreHandProps) ~= PlayerPedId() and GetEntityRotation(self.tyreHandProps).y < -5.0) or not self.tyreHandProps)) and true or false
                end,
                action = function()
                    DetachEntity(self.rimHandProps)
                    self:AttachRim(PlayerPedId())
                end
            },
        },
        distance = 2.5
    })


    exports[Config.QBTargetName]:AddBoxZone("wheel_machine", Config.Job.WheelMachine.QBTargetStartMachine.coords, Config.Job.WheelMachine.QBTargetStartMachine.size[1], Config.Job.WheelMachine.QBTargetStartMachine.size[2], {
        name = "wheel_machine",
        heading = 0,
        debugPoly = Config.Job.WheelMachine.QBTargetStartMachine.debug,
        minZ = Config.Job.WheelMachine.QBTargetStartMachine.minZ,
        maxZ = Config.Job.WheelMachine.QBTargetStartMachine.maxZ
    }, {
        options = {
            {
                type  = "client",
                icon  = "fas fa-gear",
                label = _Client:ToLang("START_MACHINE"),
                job   = Config.Job.Name,
                canInteract = function()
                    return (GetEntityAttachedTo(self.tyreHandProps) == self.diskProps and GetEntityAttachedTo(self.rimHandProps) == self.diskProps) and true or false
                end,
                action = function()
                    local isAWheel = false
                    if GetEntityRotation(self.tyreHandProps).y > -5.0 then
                        isAWheel = true
                    end
                    self:StartMachine(isAWheel)
                end
            },
        },
        distance = Config.Job.WheelMachine.QBTargetStartMachine.distance
    })
end

function _Wheel:StartMachine(isAWheel)
    local rotationY = isAWheel and 0.0 or -10.0

    _Client:PlaySound("launch_stick", 0.75, true, GetEntityCoords(self.diskProps), 2.5)

    Wait(4750)

    for i = 0.98, 0.635, -0.001 do
        AttachEntityToEntity(self.stickProps, self.machineProps, 0, 0.15, 0.17, i, 0.0, 0.0, 0.0, 0, 0, 1, 0, 0, 1)
        Wait(1)
    end

    Wait(500)

    _Client:PlaySound("launch_disk", 0.75, true, GetEntityCoords(self.diskProps), 2.5)

    Wait(500)

    while (isAWheel and rotationY > -10.0) or (not isAWheel and rotationY < 0.0) do
        rotationY = isAWheel and rotationY - 0.0115 or rotationY + 0.0115

        AttachEntityToEntity(self.tyreHandProps, self.diskProps, 0, 0.0, 0.0, 0.125, 90.0, rotationY, 0.0, 1, 1, 0, 0, 1, 1)

        local rotation = GetEntityRotation(self.diskProps)
        AttachEntityToEntity(self.diskProps, self.machineProps, 0, 0.15, 0.25, -0.02, 0.0, 0.0, rotation.z + 0.25, 0, 0, 1, 0, 0, 1)
        Wait(1)
    end

    for i = 0.635, 0.98, 0.001 do
        AttachEntityToEntity(self.stickProps, self.machineProps, 0, 0.15, 0.17, i, 0.0, 0.0, 0.0, 0, 0, 1, 0, 0, 1)
        Wait(1)
    end
end

function _Wheel:UpdateMachineTarget(newOptions)
    exports[Config.QBTargetName]:UpdateZoneData("wheel_machine", {
        options  = newOptions,
        distance = 2.5
    })
end

function _Wheel:UpdateShelfTarget(newOptions)
    for i = 1, #self.shelvesCoords do
        newOptions.shelfIndex = i
        exports[Config.QBTargetName]:UpdateZoneData("cyber_shelves_" .. i, {
            options = {newOptions},
            distance = 2.5
        })
    end
end

function _Wheel:Use(itemName)
    if self.isInShelf then return end

    if string.find(itemName, "tyre") then
        if self.tyreHandProps then return _Client:Notification(_Client:ToLang("TYRE_ALREADY_IN_HAND"), true) end

        local wheelType  = itemName:gsub("tyre_", "")

        TriggerServerEvent("ZL_cyber:removeItem", itemName, 1)

        self:AddProp("tyre", wheelType)
        self:AttachTyre(PlayerPedId())
    elseif string.find(itemName, "rim") then
        if self.rimHandProps then return _Client:Notification(_Client:ToLang("RIM_ALREADY_IN_HAND"), true) end

        TriggerServerEvent("ZL_cyber:removeItem", itemName, 1)
        self:AddProp("rim")
        self:AttachRim(PlayerPedId())
    end
end