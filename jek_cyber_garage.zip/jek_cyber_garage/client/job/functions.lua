function _Job:UseItem(itemName)
    if itemName == "carjack" then
        self:UseCarJack()
    end
end

function _Job:UseCarJack()
    local playerPed    = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local vehicle      = GetClosestVehicle(playerCoords, 2.5, 0, 71)

    if vehicle ~= 0 then
        if not IsEntityAVehicle(vehicle) or IsPedInAnyVehicle(playerPed, false) or not IsVehicleSeatFree(vehicle, -1) or not IsVehicleStopped(vehicle) then return end

        local boneIdLeft    = GetEntityBoneIndexByName(vehicle, "door_dside_f")
        local boneIdRight   = GetEntityBoneIndexByName(vehicle, "door_pside_f")
        local bonePosLeft   = GetWorldPositionOfEntityBone(vehicle, boneIdLeft)
        local bonePosRight  = GetWorldPositionOfEntityBone(vehicle, boneIdRight)
        local distanceLeft  = _Client:Distance(playerCoords, bonePosLeft)
        local distanceRight = _Client:Distance(playerCoords, bonePosRight)

        if distanceLeft <= 2.0 or distanceRight <= 2.0 then
            local isLeft   = distanceLeft < distanceRight and true or false
            local isRaised = Entity(vehicle).state.isRaised

            _Client:RequestDict("anim@amb@business@weed@weed_inspecting_lo_med_hi@")

            if not isRaised then
                _Client:RequestModel("prop_carjack")

                TaskTurnPedToFaceEntity(playerPed, vehicle, 0)
                TaskPlayAnim(playerPed, "anim@amb@business@weed@weed_inspecting_lo_med_hi@", "weed_crouch_checkingleaves_idle_02_inspector", 2.0, -3.5, -1, 1, false, false, false, false)

                TriggerServerEvent("ZL_cyber:removeItem", "carjack", 1)

                local vehicleCoords = GetEntityCoords(vehicle)
                local carJackProps  = CreateObject("prop_carjack", vehicleCoords, 1, 1, 1)
                FreezeEntityPosition(vehicle, true)
                FreezeEntityPosition(carJackProps, true)

                local _, groundZ = GetGroundZFor_3dCoord(vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, true)
                local zDiff = vehicleCoords.z - groundZ
                local xOffset = isLeft and -0.5 or 0.5
                local xAxis   = isLeft and -10.0 or -10.0
                local zAxis   = isLeft and 90.0 or -90.
                AttachEntityToEntity(carJackProps, vehicle, 0, xOffset, 0.0, -zDiff - 0.2, xAxis, 0.0, zAxis, false, false, false, false, 0, true)

                local coordsZ = vehicleCoords.z
                for i = 1, 10 do
                    local rotationAdd = isLeft and 1.0 or -1.0
                    SetEntityRotation(vehicle, 0.0, GetEntityRotation(vehicle).y + rotationAdd, GetEntityHeading(vehicle), 0, 0)
                    coordsZ += 0.01
                    SetEntityCoordsNoOffset(vehicle, vehicleCoords.x, vehicleCoords.y, coordsZ)
                    Wait(1000)
                end

                if Config.UseQBTarget then
                    local options = {
                        {
                            type   = "client",
                            event  = "ZL_cyber:removeCarjack",
                            icon   = "fas fa-toolbox",
                            label  = _Client:ToLang("REMOVE_CARJACK"),
                            entity = vehicle,
                            canInteract = function(vehicle)
                                local distance = _Client:Distance(GetEntityCoords(carJackProps), GetEntityCoords(PlayerPedId()))
                                return (not _Wheel.tyreHandProps and distance <= 1.5) and true or false
                            end
                        },
                    }

                    for i = 1, 4 do
                        local labelSide = string.upper(_Wheel.bones[i]:gsub("wheel_", ""))

                        table.insert(options, {
                            type = "client",
                            event = "Test:Event",
                            icon = 'fas fa-wrench',
                            label = _Client:ToLang("CARJACK_REMOVE_WHEEL_" .. labelSide),
                            canInteract = function(vehicle)
                                local boneIndex  = GetEntityBoneIndexByName(vehicle, _Wheel.bones[i])
                                local boneCoords = GetWorldPositionOfEntityBone(vehicle, boneIndex)
                                local boneDistance = _Client:Distance(GetEntityCoords(PlayerPedId()), boneCoords)

                                local correctSide = false
                                if string.match(labelSide, "L") then
                                    correctSide = isLeft
                                else
                                    correctSide = not isLeft
                                end

                                return (not _Wheel.tyreHandProps and correctSide and boneDistance <= 0.75) and true or false
                            end,
                            action = function(vehicle)
                                local playerPed = PlayerPedId()
                                TaskTurnPedToFaceEntity(playerPed, vehicle, 0)
                                Wait(500)
                                TaskPlayAnim(playerPed, "anim@amb@business@weed@weed_inspecting_lo_med_hi@", "weed_crouch_checkingleaves_idle_02_inspector", 3.5, -3.5, -1, 1, false, false, false, false)
                                _Client:PlaySound("wrench")
                                Wait(1000)
                                ClearPedTasks(playerPed)
                                _Wheel:RemoveVehicleWheel(vehicle, i - 1)

                                local vehicleWheelTypeIndex = GetVehicleWheelType(vehicle)
                                local vehicleWheelTypeName

                                for k,v in pairs(_Wheel.indexType) do
                                    if v == vehicleWheelTypeIndex then
                                        vehicleWheelTypeName = k
                                        break
                                    end
                                end

                                exports[Config.QBTargetName]:AddTargetEntity(vehicle, {
                                    options = {
                                        {
                                            type = "client",
                                            event = "Test:Event",
                                            icon = 'fas fa-wrench',
                                            label = _Client:ToLang("CARJACK_ADD_WHEEL_" .. labelSide),
                                            job   = Config.Job.Name,
                                            canInteract = function(vehicle, distance)
                                                local boneIndex  = GetEntityBoneIndexByName(vehicle, "suspension_" .. string.lower(labelSide))
                                                local boneCoords = GetWorldPositionOfEntityBone(vehicle, boneIndex)
                                                local boneDistance = _Client:Distance(GetEntityCoords(PlayerPedId()), boneCoords)
                                                return (_Wheel.tyreHandProps and _Wheel.rimHandProps and boneDistance <= 1.4) and true or false
                                            end,
                                            action = function(vehicle)
                                                local vehicleWheelTypeIndex = GetVehicleWheelType(vehicle)
                                                local vehicleWheelTypeName
                                                
                                                for k,v in pairs(_Wheel.indexType) do
                                                    if v == vehicleWheelTypeIndex then
                                                        vehicleWheelTypeName = k
                                                        break
                                                    end
                                                end

                                                if vehicleWheelTypeName ~= Entity(_Wheel.tyreHandProps).state.type then return _Client:Notification(_Client:ToLang("CARJACK_NO_VALID_WHEEL_TYPE"), true) end

                                                local playerPed = PlayerPedId()
                                                TaskTurnPedToFaceEntity(playerPed, vehicle, 0)
                                                Wait(500)
                                                TaskPlayAnim(playerPed, "anim@amb@business@weed@weed_inspecting_lo_med_hi@", "weed_crouch_checkingleaves_idle_02_inspector", 3.5, -3.5, -1, 1, false, false, false, false)
                                                _Client:PlaySound("wrench")
                                                Wait(1000)
                                                ClearPedTasks(playerPed)
                                                _Wheel:RemoveTyre()
                                                _Wheel:RemoveRim()
                                                _Wheel:AddVehicleWheel(vehicle, i - 1)
                                                exports[Config.QBTargetName]:RemoveTargetEntity(vehicle, { _Client:ToLang("CARJACK_ADD_WHEEL_" .. labelSide) })
                                            end
                                        }
                                    },
                                    distance = 3.5
                                })

                                _Wheel:AddProp("tyre", vehicleWheelTypeName)
                                _Wheel:AttachTyre(PlayerPedId())
                                _Wheel:AddProp("rim")
                                _Wheel:AttachRim(_Wheel.tyreHandProps)
                            end
                        })
                    end

                    exports[Config.QBTargetName]:AddTargetEntity(vehicle, {
                        options = options,
                        distance = 3.0
                    })
                else
                    Entity(carJackProps).state.vehicle = vehicle
                    table.insert(self.carjackLift, carJackProps)
                end

                ClearPedTasks(PlayerPedId())
                Entity(vehicle).state.isRaised = NetworkGetNetworkIdFromEntity(carJackProps)
                Entity(vehicle).state.isLeft   = isLeft
            else
                return _Client:Notification(_Client:ToLang("CARJACK_ALREADY_PLACED"), true)
            end
        else
            return _Client:Notification(_Client:ToLang("CARJACK_NO_SIDE_CLOSE"), true)
        end
    else
        return _Client:Notification(_Client:ToLang("CARJACK_NO_VEHICLE"), true)
    end
end

function _Job:RemoveCarjack(vehicle)
    local carJackProps = NetworkGetEntityFromNetworkId(Entity(vehicle).state.isRaised)
    local isLeft  = Entity(vehicle).state.isLeft
    if not carJackProps or not IsEntityAVehicle(vehicle) or not IsVehicleSeatFree(vehicle, -1) or not IsVehicleStopped(vehicle) then return end

    
    for i = 1, 4 do
        local labelSide = string.upper(_Wheel.bones[i]:gsub("wheel_", ""))
        local boneIndex  = GetEntityBoneIndexByName(vehicle, _Wheel.bones[i])
        local boneCoords = GetWorldPositionOfEntityBone(vehicle, boneIndex)
        local boneDistance = _Client:Distance(GetEntityCoords(PlayerPedId()), boneCoords)

        local correctSide = false
        if string.match(labelSide, "L") then
            correctSide = isLeft
        else
            correctSide = not isLeft
        end

        if correctSide then
            if boneDistance > 5.0 then
                return _Client:Notification(_Client:ToLang("CARJACK_WHEEL_NO_PLACED"), true)
            end
        end
    end

    if Config.UseQBTarget then
        exports[Config.QBTargetName]:RemoveTargetEntity(vehicle, { _Client:ToLang("REMOVE_CARJACK") })
    else
        for i = 1, #self.carjackLift do
            if self.carjackLift[i] == carJackProps then
                table.remove(self.carjackLift, i)
                break
            end
        end
    end

    local vehicleCoords  = GetEntityCoords(vehicle)
    local coordsZ = vehicleCoords.z
    for i = GetEntityRotation(vehicle).y, 0, (isLeft and -1 or 1) do
        TaskPlayAnim(PlayerPedId(), "anim@amb@business@weed@weed_inspecting_lo_med_hi@", "weed_crouch_checkingleaves_idle_02_inspector", 3.5, -3.5, -1, 1, false, false, false, false)
        Wait(500)
        SetEntityRotation(vehicle, 0.0, i, GetEntityHeading(vehicle), 0, 0)
        coordsZ -= 0.01
        SetEntityCoordsNoOffset(vehicle, vehicleCoords.x, vehicleCoords.y, coordsZ)
        Wait(1000)
    end

    ClearPedTasks(PlayerPedId())
    DeleteEntity(carJackProps)
    TriggerServerEvent("ZL_cyber:addItem", "carjack", 1)
    FreezeEntityPosition(vehicle, false)
    Entity(vehicle).state.isRaised = nil
    Entity(vehicle).state.isLeft   = nil
end

function _Job:OpenOrderPartsComputer()
    _Client:TriggerCallback("getSocietyBalance", function(balance)
        SendNuiMessage(json.encode({
            type    = "openOrder",
            test  = "tyre_f12",
            societyBalance = balance
        }))
        SetNuiFocus(true, true)
        self.computerOpened = true
    end)
end

function _Job:CloseOrderPartsComputer()
    _Client:TriggerCallback("changeOrderPartsComputerStatus", function() end)
    SetNuiFocus(false, false)
    self.computerOpened = false
end

function _Job:UpdateSocietyBalance(newBalance)
    SendNuiMessage(json.encode({
        type     = "updateSocietyBalance",
        balance  = newBalance
    }))
end

function _Job:BuyOrderBasket(data)
    data.price = tonumber(data.price)

    TriggerServerEvent("ZL_cyber:removeSocietyAccountBalance", data.price)
    TriggerServerEvent("ZL_cyber:buyOrderBasket", data.basket)
    
    _Client:Notification(_Client:ToLang("ORDER_PARTS_BUY_BASKET"):format(data.price))
end

function _Job:AddAllWheelsInteract(vehicle)
    if Config.UseQBTarget then
        local options = {}

        for i = 1, 4 do
            local labelSide = string.upper(_Wheel.bones[i]:gsub("wheel_", ""))

            table.insert(options, {
                type = "client",
                event = "Test:Event",
                icon = 'fas fa-wrench',
                label = _Client:ToLang("CARJACK_REMOVE_WHEEL_" .. labelSide),
                canInteract = function(vehicle)
                    local boneIndex  = GetEntityBoneIndexByName(vehicle, _Wheel.bones[i])
                    local boneCoords = GetWorldPositionOfEntityBone(vehicle, boneIndex)
                    local boneDistance = _Client:Distance(GetEntityCoords(PlayerPedId()), boneCoords)
                    local vehicleCoords = GetEntityCoords(vehicle)

                    return (not _Wheel.tyreHandProps and boneDistance <= 1.75 and _Client:Distance(vehicleCoords, vector3(712.5, -759.10, 25.0)) <= 10.0 and vehicleCoords.z > 26.0) and true or false
                end,
                action = function(vehicle)
                    local playerPed = PlayerPedId()
                    TaskTurnPedToFaceEntity(playerPed, vehicle, 0)
                    Wait(500)
                    _Client:PlaySound("wrench")
                    Wait(1000)
                    _Wheel:RemoveVehicleWheel(vehicle, i - 1)

                    local vehicleWheelTypeIndex = GetVehicleWheelType(vehicle)
                    local vehicleWheelTypeName

                    for k,v in pairs(_Wheel.indexType) do
                        if v == vehicleWheelTypeIndex then
                            vehicleWheelTypeName = k
                            break
                        end
                    end

                    exports[Config.QBTargetName]:AddTargetEntity(vehicle, {
                        options = {
                            {
                                type = "client",
                                event = "Test:Event",
                                icon = 'fas fa-wrench',
                                label = _Client:ToLang("CARJACK_ADD_WHEEL_" .. labelSide),
                                job   = Config.Job.Name,
                                canInteract = function(vehicle, distance)
                                    local boneIndex  = GetEntityBoneIndexByName(vehicle, "suspension_" .. string.lower(labelSide))
                                    local boneCoords = GetWorldPositionOfEntityBone(vehicle, boneIndex)
                                    local boneDistance = _Client:Distance(GetEntityCoords(PlayerPedId()), boneCoords)
                                    local vehicleCoords = GetEntityCoords(vehicle)

                                    return (_Wheel.tyreHandProps and _Wheel.rimHandProps and boneDistance <= 1.85 and _Client:Distance(vehicleCoords, vector3(712.5, -759.10, 25.0)) <= 10.0 and vehicleCoords.z > 26.0) and true or false
                                end,
                                action = function(vehicle)
                                    local vehicleWheelTypeIndex = GetVehicleWheelType(vehicle)
                                    local vehicleWheelTypeName
                                    
                                    for k,v in pairs(_Wheel.indexType) do
                                        if v == vehicleWheelTypeIndex then
                                            vehicleWheelTypeName = k
                                            break
                                        end
                                    end

                                    if vehicleWheelTypeName ~= Entity(_Wheel.tyreHandProps).state.type then return _Client:Notification(_Client:ToLang("CARJACK_NO_VALID_WHEEL_TYPE"), true) end

                                    local playerPed = PlayerPedId()
                                    TaskTurnPedToFaceEntity(playerPed, vehicle, 0)
                                    Wait(500)
                                    _Client:PlaySound("wrench")
                                    Wait(1000)
                                    _Wheel:RemoveTyre()
                                    _Wheel:RemoveRim()
                                    _Wheel:AddVehicleWheel(vehicle, i - 1)
                                    exports[Config.QBTargetName]:RemoveTargetEntity(vehicle, { _Client:ToLang("CARJACK_ADD_WHEEL_" .. labelSide) })
                                end
                            }
                        },
                        distance = 3.5
                    })

                    _Wheel:AddProp("tyre", vehicleWheelTypeName)
                    _Wheel:AttachTyre(PlayerPedId())
                    _Wheel:AddProp("rim")
                    _Wheel:AttachRim(_Wheel.tyreHandProps)
                end
            })
        end

        exports[Config.QBTargetName]:AddTargetEntity(vehicle, {
            options = options,
            distance = 3.0
        })
    else
    end
end

function _Job:RemoveAllWheelsInteract()
end

function _Job:CreateQBTarget()
    exports[Config.QBTargetName]:AddBoxZone("job_order_parts", Config.Job.OrderParts.Zone.coords, Config.Job.OrderParts.Zone.size[1], Config.Job.OrderParts.Zone.size[2], {
        name = "job_order_parts",
        heading = 0,
        debugPoly = false,
        minZ = Config.Job.OrderParts.Zone.minZ,
        maxZ = Config.Job.OrderParts.Zone.maxZ,
    }, {
        options = {
            {
                type  = "client",
                event = "ZL_cyber:openOrderParts",
                icon  = "fas fa-laptop",
                job   = Config.Job.Name,
                label = _Client:ToLang("ORDER_PARTS_OPEN_QBTARGET")
            }
        },
        distance = Config.Job.OrderParts.Zone.distance
    })
end