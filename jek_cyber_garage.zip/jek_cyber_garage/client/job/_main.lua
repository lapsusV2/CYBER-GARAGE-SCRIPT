_Job = _Client:extend()

function _Job:init()
    self.computerOpened = false
    self.carjackLift    = {}

    if Config.UseQBTarget then
        self:CreateQBTarget()
    end

    _Wheel:init()
end

function _Job:loop(playerCoords)
    local isInZone = false

    if _Client.playerData.job and Config.Job.Name == _Client.playerData.job.name then
        if _Client:Distance(Config.Job.OrderParts.Coords, playerCoords) <= 1.5 and not self.computerOpened then
            _Client:HelpNotification(Config.Job.OrderParts.Coords, _Client:ToLang("ORDER_PARTS_HELP_NOTIFICATION"):format("E"))

            if IsControlJustReleased(0, 38) then
                local isAlreadyUsed
                local waitUse = promise.new()

                _Client:TriggerCallback("changeOrderPartsComputerStatus", function(isUse)
                    isAlreadyUse = isUse         
                    waitUse:resolve()
                end)

                Citizen.Await(waitUse)

                if not isAlreadyUse then
                    self:OpenOrderPartsComputer()
                else
                    _Client:Notification(_Client:ToLang("ORDER_PARTS_ALREADY_IN_USE"), true)
                end
            end

            isInZone = true
        end 
    end

    for i = 1, #self.carjackLift do
        local vehicle = Entity(self.carjackLift[i]).state.vehicle
        local coords  = GetEntityCoords(self.carjackLift[i])
        if _Client:Distance(coords, GetEntityCoords(PlayerPedId())) < 1.4 then
            _Client:HelpNotification(coords, _Client:ToLang("CARJACK_REMOVE_HELP_NOTIFICATION"):format("E"))
            
            if IsControlJustReleased(0, 38) then
                self:RemoveCarjack(vehicle)
            end
        
            isInZone = true

            goto endCarlift
        end

        for wheelIndex = 1, 4 do
            local isLeft       = Entity(vehicle).state.isLeft
            local labelSide    = string.upper(_Wheel.bones[wheelIndex]:gsub("wheel_", ""))

            local correctSide = false
            if string.match(labelSide, "L") then
                correctSide = isLeft
            else
                correctSide = not isLeft
            end

            if correctSide then
                local wheelBoneIndex    = GetEntityBoneIndexByName(vehicle, _Wheel.bones[wheelIndex])
                local wheelBoneCoords   = GetWorldPositionOfEntityBone(vehicle, wheelBoneIndex)
                local wheelBoneDistance = _Client:Distance(GetEntityCoords(PlayerPedId()), wheelBoneCoords)
                local suspensionBoneIndex  = GetEntityBoneIndexByName(vehicle, "suspension_" .. string.lower(labelSide))
                local suspensionBoneCoords = GetWorldPositionOfEntityBone(vehicle, suspensionBoneIndex)
                local suspensionBoneDistance = _Client:Distance(GetEntityCoords(PlayerPedId()), suspensionBoneCoords)

                if suspensionBoneDistance <= 1.4 and wheelBoneDistance >= 5.0 then
                    if GetEntityAttachedTo(_Wheel.tyreHandProps) == PlayerPedId() and GetEntityAttachedTo(_Wheel.rimHandProps) == _Wheel.tyreHandProps then
                        _Client:HelpNotification(boneCoords, _Client:ToLang("CARJACK_ADD_WHEEL_" .. labelSide .. "_HELP_NOTIFICATION"):format("E"))

                        if IsControlJustReleased(0, 38) then

                            local vehicleWheelTypeIndex = GetVehicleWheelType(vehicle)
                            local vehicleWheelTypeName
                            
                            for k,v in pairs(_Wheel.indexType) do
                                if v == vehicleWheelTypeIndex then
                                    vehicleWheelTypeName = k
                                    break
                                end
                            end

                            if vehicleWheelTypeName ~= Entity(_Wheel.tyreHandProps).state.type then return _Client:Notification(_Client:ToLang("CARJACK_NO_VALID_WHEEL_TYPE"), true) end

                            local playerPed = PlayerPedId()
                            TaskTurnPedToFaceEntity(playerPed, vehicle, 0)
                            Wait(500)
                            TaskPlayAnim(playerPed, "anim@amb@business@weed@weed_inspecting_lo_med_hi@", "weed_crouch_checkingleaves_idle_02_inspector", 3.5, -3.5, -1, 1, false, false, false, false)
                            _Client:PlaySound("wrench")
                            Wait(1000)
                            ClearPedTasks(playerPed)
                            _Wheel:RemoveTyre()
                            _Wheel:RemoveRim()
                            _Wheel:AddVehicleWheel(vehicle, wheelIndex - 1)
                        end

                        isInZone = true
                    
                        goto endCarlift
                    end
                else
                    if not _Wheel.tyreHandProps and wheelBoneDistance <= 1.0 then
                        _Client:HelpNotification(boneCoords, _Client:ToLang("CARJACK_REMOVE_WHEEL_" .. labelSide .. "_HELP_NOTIFICATION"):format("E"))

                        if IsControlJustReleased(0, 38) then
                            local playerPed = PlayerPedId()
                            TaskTurnPedToFaceEntity(playerPed, vehicle, 0)
                            Wait(500)
                            TaskPlayAnim(playerPed, "anim@amb@business@weed@weed_inspecting_lo_med_hi@", "weed_crouch_checkingleaves_idle_02_inspector", 3.5, -3.5, -1, 1, false, false, false, false)
                            _Client:PlaySound("wrench")
                            Wait(1000)
                            ClearPedTasks(playerPed)
                            _Wheel:RemoveVehicleWheel(vehicle, wheelIndex - 1)

                            local vehicleWheelTypeIndex = GetVehicleWheelType(vehicle)
                            local vehicleWheelTypeName

                            for k,v in pairs(_Wheel.indexType) do
                                if v == vehicleWheelTypeIndex then
                                    vehicleWheelTypeName = k
                                    break
                                end
                            end

                            _Wheel:AddProp("tyre", vehicleWheelTypeName)
                            _Wheel:AttachTyre(PlayerPedId())
                            _Wheel:AddProp("rim")
                            _Wheel:AttachRim(_Wheel.tyreHandProps)
                        end

                        isInZone = true
                        
                        goto endCarlift
                    end
                end
            end
        end
    end

    ::endCarlift::

    return isInZone
end

RegisterNetEvent("ZL_cyber:openOrderParts", function()
    local isAlreadyUsed
    local waitUse = promise.new()

    _Client:TriggerCallback("changeOrderPartsComputerStatus", function(isUse)
        isAlreadyUse = isUse         
        waitUse:resolve()
    end)

    Citizen.Await(waitUse)

    if not isAlreadyUse then
        _Job:OpenOrderPartsComputer()
    else
        _Client:Notification(_Client:ToLang("ORDER_PARTS_ALREADY_IN_USE"), true)
    end
end)

RegisterNetEvent("ZL_cyber:removeCarjack", function(data)
    _Job:RemoveCarjack(data.entity)
end)

RegisterNUICallback("onCloseOrder", function()
    _Job:CloseOrderPartsComputer()
end)

RegisterNUICallback("buyOrderBasket", function(data)
    _Job:BuyOrderBasket(data)
end)