_Lift = _Client:extend()

function _Lift:init()
    self.props = {}
    self.open  = false
    self.currentIndex  = nil
    self.currentAction  = {}
    self.liftButtonCoords = Config.Lift.Coords.Controllers

    --Config.Lift.MaxHeight     = Config.Lift.MaxHeight < 23.92 and 23.92 or Config.Lift.MaxHeight
    --Config.Lift.DefaultHeight = Config.Lift.DefaultHeight > Config.Lift.MaxHeight and Config.Lift.MaxHeight or Config.Lift.DefaultHeight
    --Config.Lift.DefaultHeight = Config.Lift.DefaultHeight < 23.92 and 23.92 or Config.Lift.DefaultHeight

    if Config.UseQBTarget then
        self:CreateQBTarget()
    end

    _Client:TriggerCallback("getLifts", function(lifts)
        self:CreateLiftsProps(lifts)
    end)
end

function _Lift:loop(playerCoords)
    local isInZone     = false

    if (Config.Lift.OnlyForJob and Config.Job.Activated and Config.Job.Name == _Client.playerData.job.name) or not Config.Job.Activated then
        for i = 1, #self.liftButtonCoords do
            if _Client:Distance(playerCoords, self.liftButtonCoords[i]) <= 2.0 then
                _Client:HelpNotification(self.liftButtonCoords[i], _Client:ToLang("LIFT_HELP_NOTIFICATION"):format("E"))

                if IsControlJustPressed(0, 38) then
                    self:display(i, true)
                end

                isInZone = true
            end
        end
    end

    return isInZone
end

RegisterNetEvent("ZL_cyber:displayLiftController", function(data)
    if _Lift.open then return end
    _Lift:display(data.liftIndex, true)
end)

RegisterNUICallback("onClickControllerButton", function(index)
    if index == 1 then
        TriggerServerEvent("ZL_cyber:executeLiftAction", _Lift.currentIndex, "UP")
    elseif index == 2 then
        local x,y,z = table.unpack(GetEntityCoords(_Lift.props[_Lift.currentIndex]))
        TriggerServerEvent("ZL_cyber:executeLiftAction", _Lift.currentIndex, "STOP", z)
    elseif index == 3 then
        TriggerServerEvent("ZL_cyber:executeLiftAction", _Lift.currentIndex, "DOWN")
    end
end)

RegisterNetEvent("ZL_cyber:onExecuteLiftAction", function(index, action)
    if not DoesEntityExist(_Lift.props[index]) then
        _Client:TriggerCallback("getLifts", function(lifts)
            self:CreateLiftsProps(lifts)
        end)
    end

    if action == "UP" then
        _Lift:Up(index)
    elseif action == "STOP" then
        _Lift.currentAction[index] = "STOP"
    elseif action == "DOWN" then
        _Lift:Down(index)
    end
end)

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName == GetCurrentResourceName() then
        for i = 1, #_Lift.props do
            DeleteEntity(_Lift.props[i])
        end
    end
end)