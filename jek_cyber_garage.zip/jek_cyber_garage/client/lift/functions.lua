function _Lift:CreateLiftsProps(lifts)
    for i = 1, #lifts do
        local liftConfig = Config.Lift.Types[lifts[i].type]
        _Client:RequestModel(liftConfig.Model)
        local object = CreateObject(liftConfig.Model, lifts[i].coords.x, lifts[i].coords.y, liftConfig.DefaultHeight, 0, 1, 0)
        SetEntityCoords(object, lifts[i].coords.x, lifts[i].coords.y, liftConfig.DefaultHeight)
        SetEntityLodDist(object, 0xFFFF)
        SetEntityCollision(object, true, true)
        FreezeEntityPosition(object, true)

        SetEntityHeading(object, lifts[i].heading)

        Entity(object).state.type = lifts[i].type

        self.props[i] = object
    end
end

function _Lift:display(index, boolean)
    local boolean = boolean or false
    local waitUse = promise.new()
    local isAlreadyUse = false

    _Client:TriggerCallback("changeLiftStatus", function(newIsAlreadyUse)
        isAlreadyUse = newIsAlreadyUse

        waitUse:resolve()
    end, index)

    Citizen.Await(waitUse)

    if isAlreadyUse then return _Client:Notification(_Client:ToLang("LIFT_ALREADY_IN_USE"), true) end

    SendNuiMessage(json.encode({
        type    = "displayController",
        boolean = boolean,
        index   = index
    }))
    SetNuiFocus(boolean, boolean)
    SetNuiFocusKeepInput(boolean)

    self.open         = boolean
    self.currentIndex = boolean and index or nil

    while self.open do
        local playerPed = PlayerPedId()
        DisablePlayerFiring(playerPed, true)
        SetPedCanPlayGestureAnims(playerPed, false)
        DisableControlAction(0, 1, true)
        DisableControlAction(0, 2, true)
        DisableControlAction(0, 91, true)
        DisableControlAction(0, 92, true)
        DisableControlAction(0,263,true)
        DisableControlAction(0,264,true)
        DisableControlAction(0,257,true)
        DisableControlAction(0,140,true)
        DisableControlAction(0,141,true)
        DisableControlAction(0,142,true)
        DisableControlAction(0,143,true)

        if IsControlJustReleased(0, 202) then
            self:display(index)
        end

        if _Client:Distance(GetEntityCoords(playerPed), self.liftButtonCoords[index]) >= 3.0 then
            self:display(index)
        end

        Wait(1)
    end
end

function _Lift:Up(index)
    if self.currentAction[index] == "UP" then return end

    CreateThread(function()
        self.currentAction[index] = "UP"

        local x,y,z = table.unpack(GetEntityCoords(self.props[index]))
        local maxHeight = false
        local vehicle = GetClosestVehicle(x, y, z, 2.0, 0, 71)
        local vehCoords = GetEntityCoords(vehicle)
        local vehZ = vehCoords.z
        local vehOoo = 0
        while not maxHeight and self.currentAction[index] == "UP" do
            local x,y,z = table.unpack(GetEntityCoords(self.props[index]))

            if (Config.Lift.Types[Entity(self.props[index]).state.type].MaxHeight - z > Config.Lift.DistanceToSlow) then
                SetEntityCoords(self.props[index], x, y, z + Config.Lift.Speed)
                vehZ += Config.Lift.Speed
                if Entity(self.props[index]).state.type == "yellow" and DoesEntityExist(vehicle) and NetworkHasControlOfEntity(vehicle) and vehZ - Config.Lift.Types[Entity(self.props[index]).state.type].MinHeight > 0.15 then
                    SetEntityCoordsNoOffset(vehicle, vehCoords.x, vehCoords.y, vehZ)
                end
            else
                SetEntityCoords(self.props[index], x, y, z + Config.Lift.SpeedSlow)
                vehZ += Config.Lift.SpeedSlow
                if Entity(self.props[index]).state.type == "yellow" and NetworkHasControlOfEntity(vehicle) and vehZ - Config.Lift.Types[Entity(self.props[index]).state.type].MinHeight > 0.15 then
                    SetEntityCoordsNoOffset(vehicle, vehCoords.x, vehCoords.y, vehZ)
                end

                if (z > Config.Lift.Types[Entity(self.props[index]).state.type].MaxHeight) then
                    maxHeight = true
                end
            end

            Wait(1)
        end

        if vehicle then
            _Job:RemoveAllWheelsInteract(vehicle)
        end

        if maxHeight then
            SendNuiMessage(json.encode({
                type = "changeButtonStatus"
            }))

            self.currentAction[index] = nil

            if vehicle then
                _Job:AddAllWheelsInteract(vehicle)
            end
        end
    end)
end

function _Lift:Down(index)
    if self.currentAction[index] == "DOWN" then return end

    CreateThread(function()
        self.currentAction[index] = "DOWN"

        local x,y,z = table.unpack(GetEntityCoords(self.props[index]))
        local vehicle = GetClosestVehicle(x, y, z, 2.0, 0, 71)
        local vehCoords = GetEntityCoords(vehicle)
        local vehZ = vehCoords.z
        local minHeight = false
        while not minHeight and self.currentAction[index] == "DOWN" do
            local x,y,z = table.unpack(GetEntityCoords(self.props[index]))

            if (z - Config.Lift.Types[Entity(self.props[index]).state.type].MinHeight > Config.Lift.DistanceToSlow) then
                SetEntityCoords(self.props[index], x, y, z - Config.Lift.Speed)
                vehZ -= Config.Lift.Speed
                if Entity(self.props[index]).state.type == "yellow" and NetworkHasControlOfEntity(vehicle) and vehZ - Config.Lift.Types[Entity(self.props[index]).state.type].MinHeight > 0.15 then
                    SetEntityCoordsNoOffset(vehicle, vehCoords.x, vehCoords.y, vehZ)
                end
            else
                SetEntityCoords(self.props[index], x, y, z - Config.Lift.SpeedSlow)
                vehZ -= Config.Lift.SpeedSlow
                if Entity(self.props[index]).state.type == "yellow" and NetworkHasControlOfEntity(vehicle) and vehZ - Config.Lift.Types[Entity(self.props[index]).state.type].MinHeight > 0.15 then
                    SetEntityCoordsNoOffset(vehicle, vehCoords.x, vehCoords.y, vehZ)
                end
                
                if (z < Config.Lift.Types[Entity(self.props[index]).state.type].MinHeight) then
                    minHeight = true
                end
            end

            Wait(1)
        end

        if vehicle then
            _Job:RemoveAllWheelsInteract(vehicle)
        end

        if minHeight then
            SendNuiMessage(json.encode({
                type = "changeButtonStatus"
            }))

            self.currentAction[index] = nil
        end
    end)
end

function _Lift:CreateQBTarget()
    for i = 1, #self.liftButtonCoords do
        exports[Config.QBTargetName]:AddBoxZone("CyberLiftBox_" .. i, self.liftButtonCoords[i], 0.3, 0.3, {
            name = "CyberLiftBox_" .. i,
            heading = 0,
            debugPoly = false,
            minZ = 25.4,
            maxZ = 26.3
        }, {
            options = {
                {
                    type  = "client",
                    event = "ZL_cyber:displayLiftController",
                    icon  = "fas fa-car",
                    label = _Client:ToLang("GET_LIFT_REMOTE_CONTROL"),
                    job   = (Config.Lift.OnlyForJob and Config.Job.Activated) and Config.Job.Name or nil,
                    liftIndex = i
                }
            },
            distance = 2.5
        })
    end
end