_Paint = _Client:extend()

function _Paint:init()
    self.open          = false
    self.inUse         = false
    self.particlesDict = "des_vaultdoor"
    self.particlesName = "ent_ray_pro_door_steam"
    self.particles = {}
    self.particlesCoords = Config.Paint.Coords.Particles
    self.paintCoords = Config.Paint.Coords.Interaction
    self.carPaintCoords = Config.Paint.Coords.Car
    self.carTpPaintCoords = Config.Paint.Coords.CarTp
    self.paintIndex = {
        ["NORMAL"] = {0, 0},
        ["CLASSIC"] = {0, 0},
        ["METALLIC"] = {1, 0},
        ["PEARL"]    = {2, 0},
        ["MATTE"]    = {3, 12},
        ["METALS"]   = {4, 12},
        ["CHROME"]   = {5, 120}
    }

    if Config.UseQBTarget then
        self:CreateQBTarget()
    end

end

function _Paint:loop(playerCoords)
    local isInZone     = false

    if (Config.Paint.OnlyForJob and Config.Job.Activated and Config.Job.Name == _Client.playerData.job.name) or not Config.Job.Activated then
        if _Client:Distance(playerCoords, self.paintCoords) <= 2.0 then
            _Client:HelpNotification(self.paintCoords, _Client:ToLang("PAINT_HELP_NOTIFICATION"):format("E"))

            if IsControlJustPressed(0, 38) then
                self:display(true)
            end

            isInZone = true
        end
    end

    return isInZone
end

RegisterNetEvent("ZL_cyber:openPainting", function()
    if _Paint.open then return _Client:Notification(_Client:ToLang("PAINT_ALREADY_IN_USE"), true) end

    _Paint:display(true)
end)

RegisterNUICallback("onClickPaintButton", function(data)
    _Paint:startPainting(data)
end)

RegisterNetEvent("ZL_cyber:startPaintingEffect", function(data)
    _Paint:startPaintingEffect(data)
end)

RegisterNetEvent("ZL_cyber:stopPaintingEffect", function(color, netId)
    _Paint:stopPaintingEffect(color, netId)
end)