function _Paint:display(boolean)
    local boolean = boolean or false
    local prom = promise.new()
    local isAlreadyUse = false

    _Client:TriggerCallback("changePaintStatus", function(newIsAlreadyUse)
        isAlreadyUse = newIsAlreadyUse
        prom:resolve()
    end)

    Citizen.Await(prom)

    if isAlreadyUse then return _Client:Notification(_Client:ToLang("PAINT_ALREADY_IN_USE"), true) end

    SendNuiMessage(json.encode({
        type    = "openPainting",
        boolean = boolean,
    }))
    SetNuiFocus(boolean, boolean)
    SetNuiFocusKeepInput(boolean)

    self.open = boolean

    while self.open do
        local playerPed = PlayerPedId()
        DisablePlayerFiring(playerPed, true)
        SetPedCanPlayGestureAnims(playerPed, false)
        DisableControlAction(0, 1, true)
        DisableControlAction(0, 2, true)
        DisableControlAction(0, 91, true)
        DisableControlAction(0, 92, true)
        DisableControlAction(0,263,true)
        DisableControlAction(0,264,true)
        DisableControlAction(0,257,true)
        DisableControlAction(0,140,true)
        DisableControlAction(0,141,true)
        DisableControlAction(0,142,true)
        DisableControlAction(0,143,true)

        if IsControlJustReleased(0, 202) then
            self:display()
        end

        if _Client:Distance(GetEntityCoords(playerPed), self.paintCoords) >= 2.0 then
            self:display()
        end

        Wait(1)
    end
end

function _Paint:startPainting(data)
    if self.inUse then return end

    local closestVehicle = GetClosestVehicle(self.carPaintCoords, 2.5, 0, 71)
    if closestVehicle == 0 then return _Client:Notification(_Client:ToLang("PAINT_NO_VEHICLE"), true) end

    NetworkRequestControlOfEntity(closestVehicle)
    while not NetworkHasControlOfEntity(closestVehicle) do
        Wait(10)
    end
    FreezeEntityPosition(closestVehicle, true)
    if self.carTpPaintCoords then
        SetEntityCoords(closestVehicle, self.carTpPaintCoords)
    end

    if data.options.type ~= "PEARLESCENT" then
        TriggerServerEvent("ZL_cyber:startPaintingEffect", data)

        local vehiclePaintType, vehicleColour
        local r,g,b

        if string.lower(data.options.type) == "primary" then
            vehiclePaintType, vehicleColour = GetVehicleModColor_1(closestVehicle)
            r,g,b = GetVehicleCustomPrimaryColour(closestVehicle)

            SetVehicleModColor_1(closestVehicle, self.paintIndex[string.upper(data.options.matter)][1], vehicleColour, 0)

            local _, colorSecondary = GetVehicleColours(closestVehicle)
            SetVehicleColours(closestVehicle, self.paintIndex[string.upper(data.options.matter)][2], colorSecondary)

        elseif string.lower(data.options.type) == "secondary" then
            vehiclePaintType, vehicleColour = GetVehicleModColor_2(closestVehicle)
            r,g,b = GetVehicleCustomSecondaryColour(closestVehicle)

            SetVehicleModColor_2(closestVehicle, self.paintIndex[string.upper(data.options.matter)][1], vehicleColour, 0)

            local colorPrimary, _ = GetVehicleColours(closestVehicle)
            SetVehicleColours(closestVehicle, colorPrimary, self.paintIndex[string.upper(data.options.matter)][2])
        end

        if Config.Paint.WashVehicle then
            SetVehicleDirtLevel(closestVehicle, 0)
        end

        for i = 0.0, 1.1, 0.01 do
            local color = self:LerpColor(i, {r = r, g = g, b = b}, {r = data.color.r, g = data.color.g, b = data.color.b})

            if string.lower(data.options.type) == "primary" then
                SetVehicleCustomPrimaryColour(closestVehicle, math.floor(color.r), math.floor(color.g), math.floor(color.b))
            elseif string.lower(data.options.type) == "secondary" then
                SetVehicleCustomSecondaryColour(closestVehicle, math.floor(color.r), math.floor(color.g), math.floor(color.b))
            end

            Wait(Config.Paint.Time / 110)
        end
    else
        data.color = { r = 255, g = 255, b = 255 }
        TriggerServerEvent("ZL_cyber:startPaintingEffect", data)

        local _, wheelColor = GetVehicleExtraColours(closestVehicle)
        SetVehicleExtraColours(closestVehicle, Config.Paint.PearlescentColors[data.options.pearlescentColor], wheelColor)

        if Config.Paint.WashVehicle then
            SetVehicleDirtLevel(closestVehicle, 0)
        end

        Wait(15000)
    end

    FreezeEntityPosition(closestVehicle, false)
    _Client:SaveVehicle(closestVehicle)

    local netId = NetworkGetNetworkIdFromEntity(closestVehicle)
    TriggerServerEvent("ZL_cyber:stopPaintingEffect", data.color, netId)
end

function _Paint:startPaintingEffect(data)
    if self.inUse then return end

    SendNuiMessage(json.encode({
        type    = "updatePaintingStatus",
        boolean = true
    }))

    self.inUse = true

    _Client:RequestPtfxAssetDict(self.particlesDict)

    while self.inUse do
        for i = 1, #self.particlesCoords do
            UseParticleFxAssetNextCall(self.particlesDict)
            SetParticleFxNonLoopedColour(data.color.r / 255, data.color.g / 255, data.color.b / 255)
            SetParticleFxNonLoopedAlpha(1.0)
            StartNetworkedParticleFxNonLoopedAtCoord(self.particlesName, self.particlesCoords[i][1], self.particlesCoords[i][2], self.particlesCoords[i][3], self.particlesCoords[i][4], self.particlesCoords[i][5], self.particlesCoords[i][6], 1.2, 0.0, 0.0, 0.0)
        end
        Wait(500)
    end
end

function _Paint:stopPaintingEffect(color, netId)
    self.inUse = false

    if Config.Paint.SmokeAfter then
        _Client:RequestPtfxAssetDict("scr_paintnspray")

        local entity = NetworkGetEntityFromNetworkId(netId)
        local number = 0
        while number < math.floor(Config.Paint.SmokeAfterTime / 5000) do
            UseParticleFxAssetNextCall("scr_paintnspray")
            SetParticleFxNonLoopedColour(color.r / 255, color.g / 255, color.b / 255)
            SetParticleFxNonLoopedAlpha(Config.Paint.SmokeAfterOpacity)
            StartNetworkedParticleFxNonLoopedOnEntity("scr_respray_smoke", entity, 0.0, -0.8, 0.0, -90.0, 90.0, -90.0, 0.8, 30.0, 0, 0)

            number += 1
            Wait(5000)
        end
    end

    SendNuiMessage(json.encode({
        type    = "updatePaintingStatus",
        boolean = false
    }))
end

function _Paint:LerpColor(delta, from, to)
	local fromR, toR = from.r, to.r
	local fromG, toG = from.g, to.g
	local fromB, toB = from.b, to.b
	local fromA, toA = 255, 255

	return setmetatable({
		r = (delta > 1 and toR) or (delta < 0 and fromR) or (fromR + (toR - fromR) * delta),
		g = (delta > 1 and toG) or (delta < 0 and fromG) or (fromG + (toG - fromG) * delta),
		b = (delta > 1 and toB) or (delta < 0 and fromB) or (fromB + (toB - fromB) * delta),
		a = (delta > 1 and toA) or (delta < 0 and fromA) or (fromA + (toA - fromA) * delta)
	}, debug.getregistry().Color)
end

function _Paint:CreateQBTarget()
    exports[Config.QBTargetName]:AddBoxZone("jek_cyber_paint", Config.Paint.Coords.QBTarget.coords, Config.Paint.Coords.QBTarget.size[1], Config.Paint.Coords.QBTarget.size[2], {
        name = "jek_cyber_paint",
        heading = 0,
        debugPoly = false,
        minZ = Config.Paint.Coords.QBTarget.minZ,
        maxZ = Config.Paint.Coords.QBTarget.maxZ
    }, {
        options = {
            {
                type  = "client",
                event = "ZL_cyber:openPainting",
                icon  = "fas fa-paintbrush",
                job   = (Config.Paint.OnlyForJob and Config.Job.Activated) and Config.Job.Name or nil,
                label = _Client:ToLang("PAINT_OPEN_QBTARGET")
            }
        },
        distance = 2.5
    })
end