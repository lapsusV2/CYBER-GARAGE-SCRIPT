fx_version 'adamant'
game 'gta5'
lua54 'yes'

version '1.0.5'

ui_page "html/dist/index.html"
files {
    "html/dist/**"
}

shared_scripts {
    "config/shared/*.lua",
}

client_scripts {
    "client/**",
    "config/config.utils.lua"
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',	
    "server/**.lua",
    "config/config.utils.lua"
}

escrow_ignore {
    "config/shared/config.lua",
    "config/shared/config_framework.lua",
    "config/shared/config_job.lua",
    "config/shared/config_lift.lua",
    "config/shared/config_paint.lua",
    "config/shared/translations.lua",
    "config/config.utils.lua",
}