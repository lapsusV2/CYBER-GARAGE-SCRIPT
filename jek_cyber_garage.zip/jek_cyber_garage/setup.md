# SETUP SCRIPT
    Choose your framework options in config_framework.lua
    Check functions in config.utils.lua
    Change translations languages in translations.lua



# SETUP QB CORE

    - ITEMS ( QB-CORE/SHARED/ITEMS.LUA )

        -- JEK_CYBER
            ['tyre_sport']		= {['name'] = 'tyre_sport', 		['label'] = 'Tyre Sport', 		['weight'] = 1, 		['type'] = 'item', 		['image'] = 'tyre_sport.png', 		        ['unique'] = false,     ['useable'] = true, 	['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = 'A tyre'},
            ['tyre_tuner'] 		= {['name'] = 'tyre_tuner', 		['label'] = 'Tyre Tuner', 		['weight'] = 1, 		['type'] = 'item', 		['image'] = 'tyre_tuner.png', 		        ['unique'] = false,     ['useable'] = true, 	['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = 'A tyre'},
            ['tyre_motorcycle'] = {['name'] = 'tyre_motorcycle', 	['label'] = 'Tyre Motorcycle', 	['weight'] = 1, 		['type'] = 'item', 		['image'] = 'tyre_motorcycle.png', 		        ['unique'] = false,     ['useable'] = true, 	['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = 'A tyre'},
            ['tyre_bennys'] 	= {['name'] = 'tyre_bennys', 		['label'] = 'Tyre Bennys', 		['weight'] = 1, 		['type'] = 'item', 		['image'] = 'tyre_bennys.png', 		        ['unique'] = false,     ['useable'] = true, 	['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = 'A tyre'},
            ['tyre_highend'] 	= {['name'] = 'tyre_highend', 		['label'] = 'Tyre Highend', 	['weight'] = 1, 		['type'] = 'item', 		['image'] = 'tyre_highend.png', 		        ['unique'] = false,     ['useable'] = true, 	['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = 'A tyre'},
            ['tyre_f1'] 		= {['name'] = 'tyre_f1', 			['label'] = 'Tyre F1', 			['weight'] = 1, 		['type'] = 'item', 		['image'] = 'tyre_f1.png', 		        ['unique'] = false,     ['useable'] = true, 	['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = 'A tyre'},
            ['tyre_bespoke'] 	= {['name'] = 'tyre_bespoke', 		['label'] = 'Tyre Bespoke', 	['weight'] = 1, 		['type'] = 'item', 		['image'] = 'tyre_bespoke.png', 		        ['unique'] = false,     ['useable'] = true, 	['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = 'A tyre'},
            ['tyre_street'] 	= {['name'] = 'tyre_street', 		['label'] = 'Tyre Street', 		['weight'] = 1, 		['type'] = 'item', 		['image'] = 'tyre_street.png', 		        ['unique'] = false,     ['useable'] = true, 	['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = 'A tyre'},
            ['tyre_offroad'] 	= {['name'] = 'tyre_offroad', 		['label'] = 'Tyre Offroad', 	['weight'] = 1, 		['type'] = 'item', 		['image'] = 'tyre_offroad.png', 		        ['unique'] = false,     ['useable'] = true, 	['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = 'A tyre'},
            ['tyre_lowrider'] 	= {['name'] = 'tyre_lowrider', 		['label'] = 'Tyre Lowrider', 	['weight'] = 1, 		['type'] = 'item', 		['image'] = 'tyre_lowrider.png', 		        ['unique'] = false,     ['useable'] = true, 	['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = 'A tyre'},
            ['tyre_suv'] 		= {['name'] = 'tyre_suv', 			['label'] = 'Tyre Suv', 		['weight'] = 1, 		['type'] = 'item', 		['image'] = 'tyre_suv.png', 		        ['unique'] = false,     ['useable'] = true, 	['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = 'A tyre'},
            ['tyre_muscle'] 	= {['name'] = 'tyre_muscle', 		['label'] = 'Tyre Muscle', 		['weight'] = 1, 		['type'] = 'item', 		['image'] = 'tyre_muscle.png', 		        ['unique'] = false,     ['useable'] = true, 	['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = 'A tyre'},
            
            ['carjack']         = {['name'] = 'carjack',            ['label'] = "Car Jack",         ['weight'] = 1,         ['type'] = 'item',      ['image'] = 'carjack.png',              ['unique'] = false,     ['useable'] = true,     ['shouldClose'] = true,    ['combinable'] = nil,   ['description'] = 'Car Jack'},
            ['rim']             = {['name'] = 'rim',                ['label'] = "Rim",              ['weight'] = 1,         ['type'] = 'item',      ['image'] = 'rim.png',                  ['unique'] = false,     ['useable'] = true,     ['shouldClose'] = true,    ['combinable'] = nil,   ['description'] = 'Rim'},

# SETUP ESX
        -- TABLE WITH WEIGHT SYSTEM
            CREATE TABLE IF NOT EXISTS `items` (
            `name` varchar(50) NOT NULL,
            `label` varchar(50) NOT NULL,
            `weight` int(11) NOT NULL DEFAULT 1,
            `rare` tinyint(4) NOT NULL DEFAULT 0,
            `can_remove` tinyint(4) NOT NULL DEFAULT 1,
            PRIMARY KEY (`name`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

            INSERT IGNORE INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES
                ('carjack', 'Cric de voiture', 1, 0, 1),
                ('rim', 'Jante', 1, 0, 1),
                ('tyre_bennys', 'Pneu Bennys', 1, 0, 1),
                ('tyre_bespoke', 'Pneu sur mesure', 1, 0, 1),
                ('tyre_f1', 'Pneu F1', 1, 0, 1),
                ('tyre_highend', 'Pneu Haut de gamme', 1, 0, 1),
                ('tyre_lowrider', 'Pneu Lowrider', 1, 0, 1),
                ('tyre_motorcycle', 'Pneu Moto', 1, 0, 1),
                ('tyre_muscle', 'Pneu Muscle', 1, 0, 1),
                ('tyre_offroad', 'Pneu tout terrain', 1, 0, 1),
                ('tyre_sport', 'Pneu Sport', 1, 0, 1),
                ('tyre_street', 'Pneu route', 1, 0, 1),
                ('tyre_suv', 'Pneu SUV', 1, 0, 1),
                ('tyre_tunner', 'Pneu Tuner', 1, 0, 1);

        -- TABLE WITH LIMIT SYSTEM
            CREATE TABLE IF NOT EXISTS `items` (
            `name` varchar(50) NOT NULL,
            `label` varchar(50) NOT NULL,
            `limit` int(11) NOT NULL DEFAULT 1,
            `rare` tinyint(4) NOT NULL DEFAULT 0,
            `can_remove` tinyint(4) NOT NULL DEFAULT 1,
            PRIMARY KEY (`name`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

            INSERT IGNORE INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
                ('carjack', 'Cric de voiture', 1, 0, 1),
                ('rim', 'Jante', 1, 0, 1),
                ('tyre_bennys', 'Pneu Bennys', 2, 0, 1),
                ('tyre_bespoke', 'Pneu sur mesure', 2, 0, 1),
                ('tyre_f1', 'Pneu F1', 2, 0, 1),
                ('tyre_highend', 'Pneu Haut de gamme', 2, 0, 1),
                ('tyre_lowrider', 'Pneu Lowrider', 2, 0, 1),
                ('tyre_motorcycle', 'Pneu Moto', 2, 0, 1),
                ('tyre_muscle', 'Pneu Muscle', 2, 0, 1),
                ('tyre_offroad', 'Pneu tout terrain', 2, 0, 1),
                ('tyre_sport', 'Pneu Sport', 2, 0, 1),
                ('tyre_street', 'Pneu route', 2, 0, 1),
                ('tyre_suv', 'Pneu SUV', 2, 0, 1),
                ('tyre_tunner', 'Pneu Tuner', 2, 0, 1);


        INSERT INTO `addon_account` (name, label, shared) VALUES
            ('society_mechanic', 'Mecano', 1)
        ;

        INSERT INTO `datastore` (name, label, shared) VALUES
            ('society_mechanic', 'Mecano', 1)
        ;

        INSERT INTO `addon_inventory` (name, label, shared) VALUES
            ('society_mechanic', 'Mecano', 1)
        ;

        INSERT INTO `jobs` (name, label) VALUES
            ('mechanic', 'Mecano')
        ;

        INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
            ('mechanic',0,'stagiaire','Stagiaire',20,'{}','{}'),
            ('mechanic',1,'employer','Employer',40,'{}','{}'),
            ('mechanic',2,'chef','Gérant Atelier',60,'{}','{}'),
            ('mechanic',3,'coboss','Co Patron',85,'{}','{}'),
            ('mechanic',4,'boss','Patron',100,'{}','{}')
        ;