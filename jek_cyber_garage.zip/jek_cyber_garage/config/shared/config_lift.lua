-- LIFT SYSTEM

Config.Lift = {
        Activated      = true,  -- true or false, if you want lift system or no
        Speed          = 0.0025, -- The speed of the lift
        SpeedSlow      = 0.002, -- The slow speed of the lift when is near the end
        Types          = {
                ['blue']   = {
                        Model         = "nacelle", -- don't change this
                        MaxHeight     = 26.0,  -- The max height of the blue lift (max is 27.0)
                        MinHeight     = 23.92,  -- The min height of the blue lift (min is 23.92)
                        DefaultHeight = 23.92  -- The default height of the blue lift (max is MaxHeight and min is MinHeight)
                },
                ['yellow'] = {
                        Model         = "garmx_pince", -- don't change this
                        MaxHeight     = 26.5,  -- The max height of the yellow lift (max is 27.0)
                        MinHeight     = 24.25,  -- The min height of the byellowlue lift (min is 24.2)
                        DefaultHeight = 24.25  -- The default height of the yellow lift (max is MaxHeight and min is MinHeight)
                },
        },
        DistanceToSlow = 0.2,   -- The distance before the max or min height when the slow speed activate
        OnlyForJob  = true,  -- true or false, if you want the lift is available only for job
        -- ║
        -- ║  If 'OnlyForJob' is on true
        -- ║
        -- ╚═══⋗ 
                OnlyForJobGrade = false, -- false to turn off the grade restrictions or the min grade number

        Coords = {
                Controllers = {
                        vector3(703.13, -768.05, 25.4), 
                        vector3(703.13, -762.8, 25.4), 
                        vector3(712.2, -753.4, 25.4), 
                        vector3(712.15, -759.25, 25.4)  
                },
                Ramps = {
                        {
                                coords = vector2(698.74, -769.2),
                                heading = 0,
                                type   = "blue" 
                        },
                        {
                                coords = vector2(698.74, -763.94), 
                                heading = 0,
                                type   = "blue"
                        },
                        {
                                coords = vector2(712.2, -755.1),
                                heading = 0,
                                type   = "yellow"
                        },
                        {
                                coords = vector2(712.2, -761.0),
                                heading = 0
                                type   = "yellow"
                        },
                },
        }
}