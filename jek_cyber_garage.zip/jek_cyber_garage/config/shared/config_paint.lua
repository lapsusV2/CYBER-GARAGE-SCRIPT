-- PAINT SYSTEM

Config.Paint = {
        Activated   = true,  -- true or false, if you want paint system or no
        Time        = 30000, -- time to paint a vehicle
        WashVehicle = true,  -- true or false, if you want to wash the vehicle during painting
        OnlyForJob  = true,  -- true or false, if you want the paint is available only for job
                -- ║
                -- ║  If 'OnlyForJob' is on true
                -- ║
                -- ╚═══⋗ 
                        OnlyForJobGrade = false, -- false to turn off the grade restrictions or the min grade number

        SmokeAfter = true, -- true or false, if you want the smoke after painting to represent the fresh paint
                -- ║
                -- ║ If 'SmokeAfter' is on true
                -- ║
                -- ╚═══⋗ 
                        SmokeAfterOpacity = 0.75,  -- The opacity of the smoke
                        SmokeAfterTime    = 15000, -- The time of smoke in ms (1000 ms = 1 second)

        -- Paint coords
        Coords = {
                -- Coords for QBTarget activated
                QBTarget = {
                        coords = vector3(699.05, -746.90, 25.0),
                        size   = {0.15, 0.65},
                        minZ   = 24.70,
                        maxZ   = 25.85,
                        distance = 2.5
                },

                -- Coords when QBTarget is not activated
                Interaction = vector3(699.15, -747.5, 25.4),

                -- Coords where the vehicle should be placed to paint
                Car   = vector3(696.75, -743.15, 25.0),
                CarTp = vector3(696.72, -743.6, 23.42), -- turn false if you don't want the tp

                -- Coords for paint particles
                Particles = {
                        {694.2, -744.87, 25.25, 50.0, 130.0, 0.0},
                        {699.2, -744.87, 25.25, -50.0, -130.0, -50.0},
                        {694.2, -741.4, 25.3, 50.0, 130.0, -60.0},
                        {699.2, -741.4, 25.3, -50.0, -130.0, 0.0},
                        {696.65, -739.8, 25.25, -50.0, -130.0, 55.0}
                }
        },

        Types   = {"PRIMARY", "SECONDARY", "PEARLESCENT"}, -- Paint types available in the menu
        Matters = {"NORMAL", "METALLIC", "PEARL", "MATTE", "METALS", "CHROME"}, -- Paint materials available in the menu
        PearlescentColors = { -- Pearlescent Colors available in the menu
                ["BLACK"]        = 0,
                ["CARBON_BLACK"] = 147,
                ["GRAPHITE"]     = 1,
                ["BLACK_STEEL"]  = 11,
                ["DARK_STEEL"]   = 3,
                ["SILVER"]       = 4,
                ["BLUISH_SILVER"] = 5,
                ["ROLLED_STEEL"]  = 6,
                ["SHADOW_SILVER"] = 7,
                ["STONE_SILVER"]  = 8,
                ["MIDNIGHT_SILVER"] = 9,
                ["CAST_IRON_SILVER"] = 10,
                ["RED"] = 27,
                ["TORINO_RED"] = 28,
                ["FORMULA_RED"] = 29,
                ["LAVA_RED"]  = 150,
                ["BLAZE_RED"] = 30,
                ["GRACE_RED"] = 31,
                ["GARNET_RED"] = 32,
                ["SUNSET_RED"] = 33,
                ["CABERNET_RED"] = 34,
                ["WINE_RED"]  = 143,
                ["CANDY_RED"] = 35,
                ["HOT_PINK"]  = 135,
                ["PFSITER_PINK"] = 137,
                ["SALMON_PINK"]  = 136,
                ["SUNRISE_ORANGE"] = 36,
                ["ORANGE"] = 38,
                ["BRIGHT_ORANGE"] = 138,
                ["GOLD"] = 99,
                ["BRONZE"] = 90,
                ["RACE_YELLOW"] = 89,
                ["DEW_YELLOW"]  = 91,
                ["DARK_GREEN"]  = 49,
                ["RACING_GREEN"] = 50,
                ["SEA_GREEN"] = 51,
                ["OLIVE_GREEN"] = 52,
                ["BRIGHT_GREEN"] = 53,
                ["GASOLINE_GREEN"] = 54,
                ["GALAXY_BLUE"] = 61,
                ["DARK_BLUE"] = 62,
                ["SAXON_BLUE"] = 63,
                ["BLUE"] = 64,
                ["MARINER_BLUE"] = 65,
                ["HARBOR_BLUE"]  = 66,
                ["DIAMOND_BLUE"] = 67,
                ["SURF_BLUE"] = 68,
                ["NAUTICAL_BLUE"] = 69,
                ["RACING_BLUE"]   = 73,
                ["ULTRA_BLUE"] = 70,
                ["LIGHT_BLUE"] = 74,
                ["CHOCOLATE_BROWN"] = 96,
                ["BISON_BROWN"] = 101,
                ["CREEEN_BROWN"] = 95,
                ["FELTZER_BROWN"] = 94,
                ["MAPLE_BROWN"] = 97,
                ["BEECHWOOD_BROWN"] = 103,
                ["SIENNA_BROWN"] = 104,
                ["SADDLE_BROWN"] = 98,
                ["MOSS_BROWN"] = 100,
                ["WOODBEECH_BROWN"] = 103,
                ["STRAW_BROWN"] = 99,
                ["SANDY_BROWN"] = 105,
                ["BLEACHED_BROWN"] = 106,
                ["SCHAFTER_PURPLE"] = 71,
                ["SPINNAKER_PURPLE"] = 72,
                ["MIDNIGHT_PURPLE"] = 142,
                ["BRIGHT_PURPLE"] = 145,
                ["CREAM"] = 107,
                ["ICE_WHITE"] = 111,
                ["FROST_WHITE"] = 112,
                ["GRAY"] = 13,
                ["LIGHT_GRAY"] = 14,
                ["MIDNIGHT_BLUE"] = 84,
                ["DARK_RED"] = 40,
                ["YELLOW"] = 42,
                ["LIME_GREEN"] = 55,
                ["GREEN"] = 128,
                ["FOREST_GREEN"] = 151,
                ["FOLIAGE_GREEN"] = 155,
                ["OLIVE_DARB"] = 152,
                ["DARK_EATH"] = 153,
                ["DESERT_TAN"] = 154,
                ["BRUSHED_STEEL"] = 117,
                ["BRUSHED_BLACK_STEEL"] = 118,
                ["BRUSHED_ALUMINIUM"] = 119,
                ["PURE_GOLD"] = 158,
                ["BRUSHED_GOLD"] = 159,
                ["CHROME"] = 120
        }
}