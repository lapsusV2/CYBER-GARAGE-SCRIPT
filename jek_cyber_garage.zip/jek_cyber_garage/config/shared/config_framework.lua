-- IF YOU USE CUSTOM OR OTHER FRAMEWORK MAKE TICKET ON DISCORD TO ADD IT

Config.Framework = "ESX" -- Choose the framework you use: 'ESX' or 'QBCore'

Config.UseQBTarget  = false -- If you use the interaction menu 'QB-TARGET'
        -- ║
        -- ║  If 'UseQBTarget' is on true only
        -- ║
        -- ╚═══⋗ 
                Config.QBTargetName = "qb-target" -- The name of the resource  

---  ESX
    -- ║
    -- ║
    -- ║
    -- ╚═══⋗  
            if Config.Framework == "ESX" then
                Config.EventName = {
                    getSharedObject  = "exports['es_extended']:getSharedObject()",
                    playerLoaded     = "esx:playerLoaded",
                    playerJobUpdate  = "esx:setJob",
                    societyBalanceManagement = "esx_addonaccount:getSharedAccount",
                    societyBalanceUpdateManagement = "esx_addonaccount:setMoney"
                }
            end
--- QBCore
    -- ║
    -- ║
    -- ║
    -- ╚═══⋗  
            if Config.Framework == "QBCore" then
                Config.EventName = {
                    getSharedObject  = "qb-core", -- The name of the resource  
                    playerLoaded     = "QBCore:Client:OnPlayerLoaded",
                    playerJobUpdate  = "QBCore:Client:OnJobUpdate",
                    societyBalanceManagement = "qb-management", -- The name of the resource  
                    societyBalanceUpdateManagement = "qb-management:updateMoney"
                }
            end