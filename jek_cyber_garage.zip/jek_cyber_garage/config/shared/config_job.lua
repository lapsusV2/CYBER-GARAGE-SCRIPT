-- JOB

Config.Job = {
        Activated = true,         -- true or false, if you want active the job (wheels system)
        Name     = "mechanic", -- the name(s) of the jobs (you can add job name here even without activating job system depending on your config),
        
        OrderParts = {
                Coords       = vector3(694.5, -759.1, 25.25),

                -- Parts
                Categories = {"TYRES", "TOOLS"},
                Items = {
                        ["TYRE_SPORT"]      = { price = 1,  category = "TYRES",  img = "tyre_sport" },
                        ["TYRE_MUSCLE"]     = { price = 1,  category = "TYRES",  img = "tyre_muscle" },
                        ["TYRE_LOWRIDER"]   = { price = 1,  category = "TYRES",  img = "tyre_lowrider"},
                        ["TYRE_SUV"]        = { price = 1,  category = "TYRES",  img = "tyre_suv"},
                        ["TYRE_OFFROAD"]    = { price = 1,  category = "TYRES",  img = "tyre_offroad"},
                        ["TYRE_TUNER"]      = { price = 1,  category = "TYRES",  img = "tyre_tuner"},
                        ["TYRE_MOTORCYCLE"] = { price = 1,  category = "TYRES",  img = "tyre_motorcycle"},
                        ["TYRE_HIGHEND"]    = { price = 1,  category = "TYRES",  img = "tyre_highend"},
                        ["TYRE_BENNYS"]     = { price = 1,  category = "TYRES",  img = "tyre_bennys"},
                        ["TYRE_BESPOKE"]    = { price = 1,  category = "TYRES",  img = "tyre_bespoke"},
                        ["TYRE_F1"]         = { price = 1,  category = "TYRES",  img = "tyre_f1"},
                        ["TYRE_STREET"]     = { price = 1,  category = "TYRES",  img = "tyre_street"},

                        ["CARJACK"]         = { price = 1,  category = "TOOLS",  img = "carjack"},
                        ["RIM"]             = { price = 1,  category = "TOOLS",  img = "rim"}
                },

                -- only for qb target user
                Zone = {
                        coords = vector3(694.35, -759.1, 25.0),
                        size   = {0.5, 0.5},
                        minZ   = 25.0,
                        maxZ   = 25.4,
                        distance = 2.5
                }
        },

        Shelves = {
                Coords = {
                        vector3(716.470, -752.9, 23.83),
                        vector3(716.470, -759.3, 23.83)
                },
                TyreOffset = {
                        {x = 0.0, y = -0.3, z = 0.825 },
                        {x = 0.0, y = -0.3, z = 0.825 }
                },
                TextOffset = {
                        {x = 0.0, y = -0.1, z = 1.755},
                        {x = 0.0, y = -0.1, z = 1.755}
                },
                QBTargetOffset = {
                        {x = 0.0, y = -1.7, z = 1.255},
                        {x = 0.0, y = -1.7, z = 1.255}
                },
                QBTarget = {
                        {
                                minZ = 24.0,
                                maxZ = 27.5,
                                distance = 2.5,
                                debug = false
                        },
                        {
                                minZ = 24.0,
                                maxZ = 27.5,
                                distance = 2.5,
                                debug = false
                        }
                }
        },

        WheelMachine = {
                Coords      = vector3(701.235, -756.5, 25.0),
                Interaction = vector3(701.4, -755.65, 25.0),
                TextCoords  = vector3(701.4, -755.9, 25.0),
                StartMachine = vector3(700.75, -756.60, 25.0),
                QBTargetStartMachine = {
                        coords = vector3(700.925, -756.57, 25.0),
                        size   = {0.6, 0.17},
                        minZ   = 24.5,
                        maxZ   = 24.8,
                        distance = 2.5,
                        debug  = false,
                }
        }
}