Config = {}

-- GENERAL 

Config.MappingResourceName = "CyberGarageMx" -- name of mlo resource if you buy the cyber garage or false if you don't buy it

Config.VersionCheck = true -- true or false ( If you want to be notified when a new update is available in server console )

Config.MySQL = "oxmysql" -- 'oxmysql', 'mysql-async', 'ghmattisql'

Config.HelpNotificationType = "BasicHelpNotification" -- 'BasicHelpNotification', 'DrawText3D' or 'Custom' ( work with 'CustomHelpNotification' in config.utils )
Config.NotificationType     = "BasicNotification" -- 'BasicNotification' or 'Custom' ( work with 'CustomNotification' in config.utils )