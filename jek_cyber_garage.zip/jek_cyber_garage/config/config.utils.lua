if not IsDuplicityVersion() then
    function CustomHelpNotification(x, y, z, text)
        -- Add code or export for your custom notify here
    end
    
    function CustomNotification(text, isError)
        -- Add code or export for your custom notify here
    end

    if Config.Job.Activated then
        RegisterNetEvent(Config.EventName.societyBalanceUpdateManagement, function(societyName, newBalance)
            if societyName == "society_" .. Config.Job.Name or societyName == Config.Job.Name then
                _Job:UpdateSocietyBalance(newBalance)
            end
        end)
    end
else
    if Config.Job.Activated then
        function _Server:GetSocietyAccountBalance()
            if Config.Framework == "QBCore" then
                return exports[Config.EventName.societyBalanceManagement]:GetAccount(Config.Job.Name)
            elseif Config.Framework == "ESX" then
                local balancePromise = promise.new()
                local balance = 0
    
                TriggerEvent(Config.EventName.societyBalanceManagement, "society_" .. Config.Job.Name, function(account)
                    balance = account.money
                    balancePromise:resolve()
                end)
    
                Citizen.Await(balancePromise)
    
                return balance
            end
        end
    
        function _Server:RemoveSocietyAccountBalance(amount)
            if Config.Framework == "QBCore" then
                exports[Config.EventName.societyBalanceManagement]:RemoveMoney(Config.Job.Name, amount)
            elseif Config.Framework == "ESX" then
                TriggerEvent(Config.EventName.societyBalanceManagement, "society_" .. Config.Job.Name, function(account)
                    account.removeMoney(amount)
                end)
            end
        end
    
        function _Server:RegisterUsableItem(...)
            if Config.Framework == "ESX" then
                ESX.RegisterUsableItem(...)
            elseif Config.Framework == "QBCore" then
                QBCore.Functions.CreateUseableItem(...)
            end
        end

        function _Server:AddItem(_source, itemName, count)
            itemName = string.lower(itemName)
            if Config.Framework == "ESX" then
                local xPlayer = ESX.GetPlayerFromId(_source)
                xPlayer.addInventoryItem(itemName, count)
            elseif Config.Framework == "QBCore" then
                local Player = QBCore.Functions.GetPlayer(_source)
                Player.Functions.AddItem(itemName, count, nil, {})
            end
        end

        function _Server:RemoveItem(_source, itemName, count)
            itemName = string.lower(itemName)
            if Config.Framework == "ESX" then
                local xPlayer = ESX.GetPlayerFromId(_source)
                xPlayer.removeInventoryItem(itemName, count)
            elseif Config.Framework == "QBCore" then
                local Player = QBCore.Functions.GetPlayer(_source)
                Player.Functions.RemoveItem(itemName, count, nil)
            end
        end
    
        RegisterNetEvent("ZL_cyber:addItem", function(itemName, count)
            local _source = source
            itemName = string.lower(itemName)

            _Server:AddItem(_source, itemName, count)
        end)
    
        RegisterNetEvent("ZL_cyber:removeItem", function(itemName, count)
            local _source = source
            itemName = string.lower(itemName)
    
            _Server:RemoveItem(_source, itemName, count)
        end)

        RegisterNetEvent("ZL_cyber:saveVehicle", function(vehicleProperties)
            if Config.Framework == "ESX" then
                _Server:ExecuteSQL("execute", "UPDATE owned_vehicles SET vehicle = ? WHERE plate = ?", { json.encode(vehicleProperties), vehicleProperties.plate })
            elseif Config.Framework == "QBCore" then
                _Server:ExecuteSQL("execute", "UPDATE player_vehicles SET mods = ? WHERE plate = ?", { json.encode(vehicleProperties), vehicleProperties.plate })
            end
        end)
    end
end