if Config.VersionCheck then
    CreateThread(function()
        Wait(10000)
        local resourceName   = GetCurrentResourceName()
        local currentVersion = GetResourceMetadata(resourceName, "version", 0)
        PerformHttpRequest("https://raw.githubusercontent.com/MrJekylleOFF/check_version/master/cyber_garage_script.txt", function(error, result, headers)
            if not result then return end
            local result = json.decode(result:sub(1, -2))
            local currentVersionSub = currentVersion:gsub('%.', '')
            local resultVersionSub = result.version:gsub('%.', '')

            if tonumber(resultVersionSub) > tonumber(currentVersionSub) then
                local symbols = '^4'
                for i = 1, 26 + #resourceName do
                    symbols = symbols .. '='
                end
                symbols = symbols .. '^0'
                print(symbols)
                print('^2[' .. resourceName .. '] - New update is available !^0\nCurrent Version: ^5' .. currentVersion .. '^0.\nNew Version: ^5' .. result.version .. '^0.\nChanges: ^5' .. result.notes .. '^0.')
                print(symbols)
            end
        end, "GET")
    end)
end