_Paint = _Server:extend()

function _Paint:init()
    self.status = false
end

_Server:RegisterCallback("changePaintStatus", function(_source, cb)
    if not _Paint.status then
        _Paint.status = _source
        return cb(false)
    end

    if _Paint.status == _source then
        _Paint.status = false
        return cb(false)
    end

    return cb(true)
end)

RegisterNetEvent("ZL_cyber:startPaintingEffect", function(data)
    TriggerClientEvent("ZL_cyber:startPaintingEffect", -1, data)
end)

RegisterNetEvent("ZL_cyber:stopPaintingEffect", function(color, netId)
    TriggerClientEvent("ZL_cyber:stopPaintingEffect", -1, color, netId)
end)