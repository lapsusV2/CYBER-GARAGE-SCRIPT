function _Wheel:InitTyresShelves()
    for index = 1, #self.shelvesCoords do
        if self.stocks["shelves_" .. index] == nil then self.stocks["shelves_" .. index] = {} end
        self.tyres[index] = {}
        for stageIndex = 1, self.stageCount do
            for tyreIndex = 1, self.countPerStage do
                if self.stocks["shelves_" .. index][tyreIndex + (11 * (stageIndex - 1))] == nil then self.stocks["shelves_" .. index][tyreIndex + (11 * (stageIndex - 1))] = false end
                if self.stocks["shelves_" .. index][tyreIndex + (11 * (stageIndex - 1))] then
                    self:CreateTyreInShelf(index, tyreIndex, stageIndex, self.stocks["shelves_" .. index][tyreIndex + (11 * (stageIndex - 1))])
                end
            end
        end
    end

    SaveResourceFile(GetCurrentResourceName(), "server/job/wheel/stocks.json", json.encode(self.stocks, {indent = true}), -1)
end

function _Wheel:PlaceTyreInShelf(shelfIndex, index, stage, wheelType)
    local _source = source

    self:CreateTyreInShelf(shelfIndex, index, stage, wheelType)
    SaveResourceFile(GetCurrentResourceName(), "server/job/wheel/stocks.json", json.encode(self.stocks, {indent = true}), -1)
    
    if _source then
        TriggerClientEvent("ZL_cyber:sendNotification", _source, "TYRE_PLACED_IN_SHELF")
    end

    TriggerClientEvent("ZL_cyber:updateTyresStocks", -1, self.stocks)
end

function _Wheel:GetTyreInShelf(shelfIndex, tyreIndex)
    local _source = source

    self:RemoveTyreInShelf(shelfIndex, tyreIndex)

    SaveResourceFile(GetCurrentResourceName(), "server/job/wheel/stocks.json", json.encode(self.stocks, {indent = true}), -1)

    if _source then
        TriggerClientEvent("ZL_cyber:sendNotification", _source, "TYRE_REMOVED_FROM_SHELF")
    end

    TriggerClientEvent("ZL_cyber:updateTyresStocks", -1, self.stocks)
end

function _Wheel:CreateTyreInShelf(shelfIndex, index, stage, wheelType)
    local x = self.shelvesCoords[shelfIndex].x + self.offset[shelfIndex].x * index
    local y = self.shelvesCoords[shelfIndex].y + self.offset[shelfIndex].y * index
    local z = self.shelvesCoords[shelfIndex].z + self.offset[shelfIndex].z * stage
    local tyre = CreateObjectNoOffset("imp_prop_impexp_tyre_03a", x, y, z, 1, 1, 0)
    while not DoesEntityExist(tyre) do
        Wait(1)
    end
    FreezeEntityPosition(tyre, true)
    SetEntityCoords(tyre, x, y, z)

    local netId = NetworkGetNetworkIdFromEntity(tyre)
    table.insert(self.tyres[shelfIndex], {
        props = tyre,
        netId = netId
    })

    local tyreIndex = index + (11 * (stage - 1))
    Entity(tyre).state.index = tyreIndex
    Entity(tyre).state.type  = wheelType
    self.stocks["shelves_" .. shelfIndex][tyreIndex] = wheelType
end

function _Wheel:RemoveTyreInShelf(shelfIndex, tyreIndex)
    for i = 1, #self.tyres[shelfIndex] do
        if Entity(self.tyres[shelfIndex][i].props).state.index == tyreIndex then
            print('ok', self.tyres[shelfIndex][i].props)
            DeleteEntity(self.tyres[shelfIndex][i].props)
            self.stocks["shelves_" .. shelfIndex][tyreIndex] = false
            table.remove(self.tyres[shelfIndex], i)
            break
        end
    end
end