_Wheel = _Job:extend()

function _Wheel:init()
    self.stocks = json.decode(LoadResourceFile(GetCurrentResourceName(), 'server/job/wheel/stocks.json'))
    self.tyres  = {}
    self.shelfStatus = {}
    self.countPerStage = 11
    self.stageCount = 4
    self.shelvesCoords = Config.Job.Shelves.Coords
    self.offset = Config.Job.Shelves.TyreOffset
    
    self:InitTyresShelves()
end

_Server:RegisterCallback("changeTyreShelfStatus", function(_source, cb, index)
    if not _Wheel.shelfStatus[index] then
        _Wheel.shelfStatus[index] = _source
        return cb(false)
    end

    if _Wheel.shelfStatus[index] == _source then
        _Wheel.shelfStatus[index] = nil
        return cb(false)
    end

    return cb(true)
end)

_Server:RegisterCallback("getTyresStocks", function(_source, cb)
    cb(_Wheel.stocks)
end)

RegisterNetEvent("ZL_cyber:placeTyreInShelf", function(shelfIndex, index, stage, wheelType)
    _Wheel:PlaceTyreInShelf(shelfIndex, index, stage, wheelType)
end)

RegisterNetEvent("ZL_cyber:getTyreInShelf", function(shelfIndex, tyreIndex)
    _Wheel:GetTyreInShelf(shelfIndex, tyreIndex)
end)

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName == GetCurrentResourceName() then
        if _Wheel and _Wheel.tyres then
            for i = 1, #_Wheel.tyres do
                for i2 = 1, #_Wheel.tyres[i] do              
                    DeleteEntity(_Wheel.tyres[i][i2].props)
                end
            end
        end
    end
end)