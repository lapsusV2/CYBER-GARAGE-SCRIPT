_Job = _Server:extend()

function _Job:init()
    _Wheel:init()

    self.orderPartsComputerStatus = false
end

_Server:RegisterCallback("changeOrderPartsComputerStatus", function(_source, cb, index)
    if not _Job.orderPartsComputerStatus then
        _Job.orderPartsComputerStatus = _source
        return cb(false)
    end

    if _Job.orderPartsComputerStatus == _source then
        _Job.orderPartsComputerStatus = nil
        return cb(false)
    end

    return cb(true)
end)

_Server:RegisterCallback("getSocietyBalance", function(_source, cb)
    cb(_Server:GetSocietyAccountBalance())
end)

RegisterNetEvent("ZL_cyber:buyOrderBasket", function(basket)
    local _source = source

    for k,v in pairs(basket) do
        _Server:AddItem(_source, k, v)
    end
end)