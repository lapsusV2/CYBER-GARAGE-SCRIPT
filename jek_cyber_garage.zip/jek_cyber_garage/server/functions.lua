function _Server:ExecuteSQL(type, query, param)
    local SQLPromise = promise.new()
    if Config.MySQL == "mysql-async" then
        if type == "execute" then
            MySQL.Async.execute(query, param, function(result) SQLPromise:resolve(result) end)
        elseif type == "fetchAll" then
            MySQL.Async.fetchAll(query, param, function(result) SQLPromise:resolve(result) end)
        end
    elseif Config.MySQL == "oxmysql" then
        if type == "execute" then
            exports['oxmysql']:execute(query, param, function(result) SQLPromise:resolve(result) end)
        elseif type == "fetchAll" then
            exports['oxmysql']:fetch(query, param, function(result) SQLPromise:resolve(result) end)
        end
    elseif Config.MySQL == "ghmattisql" then
        if type == "execute" then
            exports['ghmattisql']:execute(query, param, function(result) SQLPromise:resolve(result) end)
        elseif type == "fetchAll" then
            exports['ghmattisql']:fetch(query, param, function(result) SQLPromise:resolve(result) end)
        end
    end
    return Citizen.Await(SQLPromise)
end

function _Server:RegisterCallback(event, cb)
    AddEventHandler("jek_cyber:" .. event, cb)
    self.callbackList[event] = cb
    return AddEventHandler("jek_cyber:" .. event, cb)
end

RegisterNetEvent("jek_cyber:callback", function(event, cb, ...)
    local _source = source
    local prom    = promise.new()

    if _Server.callbackList[event] then
        prom:resolve({ ... })
        local result = Citizen.Await(prom)
        local unpack = table.unpack(result)
        local response = _Server.callbackList[event](_source, function(cb)
            Wait(1)
            TriggerClientEvent("jek_cyber:callback", _source, event, cb)
        end, unpack)
    end
end)