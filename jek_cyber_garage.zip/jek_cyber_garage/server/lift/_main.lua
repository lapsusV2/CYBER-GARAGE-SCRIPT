_Lift = _Server:extend()

function _Lift:init()
    self.list = Config.Lift.Coords.Ramps

    for i = 1, #self.list do
        local coords = self.list[i].coords

        self.list[i].coords = vector3(coords.x, coords.y, Config.Lift.Types[self.list[i].type].DefaultHeight)
    end

    self.status = {}
end

RegisterNetEvent("ZL_cyber:executeLiftAction", function(index, action, coordsZ)
    local lift = _Lift.list[index]
    if action == "UP" then
        lift.coords = vector3(lift.coords.x, lift.coords.y, Config.Lift.Types[lift.type].MinHeight)
    elseif action == "STOP" then
        lift.coords = vector3(lift.coords.x, lift.coords.y, coordsZ)
    elseif action == "DOWN" then
        lift.coords = vector3(lift.coords.x, lift.coords.y, Config.Lift.Types[lift.type].MaxHeight)
    end

    TriggerClientEvent("ZL_cyber:onExecuteLiftAction", -1, index, action)
end)

_Server:RegisterCallback("changeLiftStatus", function(_source, cb, index)
    if not _Lift.status[index] then
        _Lift.status[index] = _source
        return cb(false)
    end

    if _Lift.status[index] == _source then
        _Lift.status[index] = nil
        return cb(false)
    end

    return cb(true)
end)

_Server:RegisterCallback("getLifts", function(_source, cb)
    cb(_Lift.list)
end)